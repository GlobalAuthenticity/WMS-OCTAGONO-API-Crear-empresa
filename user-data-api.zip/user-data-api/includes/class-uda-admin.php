<?php
/**
 * Panel de administración del plugin: configuración de la API y
 * herramienta de previsualización de usuario.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Admin {

	/**
	 * Slug de la página de administración (info de usuario).
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'user-data-api';

	/**
	 * Slug de la página de administración de creación de empresas.
	 *
	 * @var string
	 */
	const PAGE_SLUG_COMPANY = 'user-data-api-crear-empresa';

	/**
	 * Acción usada como nonce de las peticiones AJAX del admin.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'uda_admin_nonce';

	/**
	 * Módulo de ajustes.
	 *
	 * @var UDA_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param UDA_Settings $settings Instancia del módulo de ajustes.
	 */
	public function __construct( UDA_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Registra los hooks necesarios de WordPress.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// Todas las acciones AJAX validan nonce + capacidad dentro de
		// cada callback (ver comprobaciones al inicio de cada método).
		add_action( 'wp_ajax_uda_generate_token', array( $this, 'ajax_generate_token' ) );
		add_action( 'wp_ajax_uda_search_users', array( $this, 'ajax_search_users' ) );
		add_action( 'wp_ajax_uda_preview_user', array( $this, 'ajax_preview_user' ) );
		add_action( 'wp_ajax_uda_crear_empresa_test', array( $this, 'ajax_crear_empresa_test' ) );
	}

	/**
	 * Registra la página del plugin y sus submenús en el menú de
	 * administración. Solo administradores (`manage_options`) pueden
	 * verlos o acceder a ellos.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( 'User Data API', 'user-data-api' ),
			__( 'User Data API', 'user-data-api' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			'dashicons-rest-api',
			66
		);

		// Al usar el mismo slug que el menú principal, este submenú
		// reemplaza el primer ítem que WordPress agrega automáticamente
		// (duplicado del título del menú), permitiendo darle una etiqueta
		// propia sin crear una página adicional.
		add_submenu_page(
			self::PAGE_SLUG,
			__( 'API info usuario', 'user-data-api' ),
			__( 'API info usuario', 'user-data-api' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);

		add_submenu_page(
			self::PAGE_SLUG,
			__( 'API Crear empresa', 'user-data-api' ),
			__( 'API Crear empresa', 'user-data-api' ),
			'manage_options',
			self::PAGE_SLUG_COMPANY,
			array( $this, 'render_company_page' )
		);
	}

	/**
	 * Encola CSS/JS del panel únicamente en la propia página del plugin.
	 *
	 * @param string $hook Hook de la pantalla de administración actual.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		$paginas_del_plugin = array(
			'toplevel_page_' . self::PAGE_SLUG,
			self::PAGE_SLUG . '_page_' . self::PAGE_SLUG_COMPANY,
		);

		if ( ! in_array( $hook, $paginas_del_plugin, true ) ) {
			return;
		}

		// WordPress renderiza los avisos ("admin_notices") de TODOS los
		// plugins activos en TODAS las páginas del admin, incluida esta,
		// y además los reubica automáticamente justo después del <h1> de
		// la página (ver wp-admin/js/common.js, moveNoticesBelowHeaderEnd),
		// que aquí es el título "User Data API" — por eso terminaban
		// insertados en medio del encabezado con fondo de marca. Esta
		// página no depende de avisos de terceros ni muestra avisos
		// propios vía admin_notices, así que se ocultan todos para no
		// romper la identidad visual del panel.
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );

		// Tipografías de la identidad de misentido.com ("El Octágono del
		// Sentido"): Taviraj (serif, encabezados) + Inter (cuerpo/UI),
		// confirmadas por inspección directa del DOM real del sitio. Si
		// Google Fonts no carga (bloqueado por red, etc.), el CSS ya trae
		// fallback a fuentes del sistema.
		wp_enqueue_style(
			'uda-admin-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Taviraj:wght@500;600&display=swap',
			array(),
			null
		);

		wp_enqueue_style( 'uda-admin', UDA_PLUGIN_URL . 'assets/css/admin.css', array( 'uda-admin-fonts' ), UDA_VERSION );
		wp_enqueue_script( 'uda-admin', UDA_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), UDA_VERSION, true );

		wp_localize_script(
			'uda-admin',
			'UDA_ADMIN',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
				'i18n'    => array(
					'searching'      => __( 'Buscando…', 'user-data-api' ),
					'noResults'      => __( 'Sin resultados.', 'user-data-api' ),
					'selectUser'     => __( 'Selecciona un usuario primero.', 'user-data-api' ),
					'loading'        => __( 'Cargando…', 'user-data-api' ),
					'tokenGenerated' => __( 'Token generado y guardado. Ya es el token activo de la API.', 'user-data-api' ),
					'confirmRegen'   => __( 'Esto reemplaza el token actual de inmediato. Cualquier integración que use el token anterior dejará de funcionar. ¿Continuar?', 'user-data-api' ),
					'error'          => __( 'Ocurrió un error inesperado.', 'user-data-api' ),
					'copied'         => __( '¡Copiado!', 'user-data-api' ),
					'copy'           => __( 'Copiar', 'user-data-api' ),
					'copyToken'      => __( 'Copiar token', 'user-data-api' ),
					'copyJson'       => __( 'Copiar JSON', 'user-data-api' ),
					'profileComplete'   => __( 'Perfil completo', 'user-data-api' ),
					'profileIncomplete' => __( 'Perfil incompleto', 'user-data-api' ),
					'testDone'          => __( 'Test realizado', 'user-data-api' ),
					'testPending'       => __( 'Test no realizado', 'user-data-api' ),
					'courseCompleted'   => __( 'Completado', 'user-data-api' ),
					'courseInProgress'  => __( 'En progreso', 'user-data-api' ),
					'courseNotStarted'  => __( 'Sin iniciar', 'user-data-api' ),
					'noCourses'         => __( 'Este usuario no tiene cursos asignados.', 'user-data-api' ),
					'noCompany'         => __( 'Sin empresa asignada', 'user-data-api' ),
					'noArea'            => __( 'Sin área asignada', 'user-data-api' ),
					'creatingCompany'   => __( 'Creando empresa…', 'user-data-api' ),
					'companyRequired'   => __( 'El nombre de la empresa es obligatorio.', 'user-data-api' ),
					'areasInvalidJson'  => __( 'El JSON de "Áreas a crear" no es válido. Revísalo o déjalo vacío.', 'user-data-api' ),
				),
			)
		);
	}

	/**
	 * Genera la documentación técnica en Markdown del endpoint de consulta
	 * de usuario (`/user` y su alias `/lookup`), pensada para que un
	 * agente de IA pueda integrar la API de forma autónoma sin acceder al
	 * código fuente del plugin.
	 *
	 * Todo el contenido (parámetros, nombres de campos, mensajes de error,
	 * estructura de respuestas) se genera a partir del comportamiento real
	 * de `UDA_Api`, `UDA_Auth` y `UDA_User_Data` — no se inventa ningún
	 * parámetro ni ejemplo que contradiga la implementación.
	 *
	 * El token Bearer se documenta con un marcador de posición
	 * ("TU_TOKEN_AQUI") en vez del token real configurado: este documento
	 * está pensado para descargarse y compartirse con herramientas
	 * externas (ej. pegarlo en un agente de IA), así que no debe llevar
	 * incrustado un secreto real del sitio.
	 *
	 * @param string $endpoint     URL completa de la ruta `/user`.
	 * @param string $endpoint_alt URL completa de la ruta alterna `/lookup`.
	 * @return string Documento en formato Markdown.
	 */
	private function build_docs_markdown_usuario( $endpoint, $endpoint_alt ) {
		return <<<MD_USUARIO
# User Data API (Octágono WMS) — Consultar usuario

> Documentación técnica generada a partir del código real del plugin (v{$this->get_plugin_version()}). Pensada para que un agente de IA integre este endpoint de forma autónoma, sin acceso al código fuente.

## 1. Endpoint

Existen dos rutas equivalentes: mismo método, misma autenticación, mismos parámetros, misma respuesta. Nunca pueden divergir en comportamiento entre sí.

| Ruta | URL completa | Notas |
|---|---|---|
| Original | `{$endpoint}` | Ruta original del plugin. |
| Alterna (recomendada) | `{$endpoint_alt}` | Usa esta si tu firewall (ej. Wordfence) bloquea rutas REST que terminan en "/user" por su regla anti-enumeración de usuarios. |

- **Método HTTP:** `POST` únicamente.
- **Formato de body:** JSON.

## 2. Autenticación

Bearer Token estático, configurado por el administrador del sitio en "User Data API" → "API info usuario". Es el mismo token para las tres rutas del plugin (`/user`, `/lookup`, `/company`).

```
Authorization: Bearer TU_TOKEN_AQUI
```

Reemplaza `TU_TOKEN_AQUI` por el token real, visible en el campo "Token de autenticación" de esa página.

### Validación del token

El servidor valida la cabecera ANTES de ejecutar cualquier lógica de negocio. Casos:

| Condición | HTTP | `code` | `message` |
|---|---|---|---|
| Falta la cabecera `Authorization` | 401 | `uda_unauthorized` | "Falta la cabecera Authorization." |
| La cabecera no tiene el formato `Bearer TOKEN` | 401 | `uda_unauthorized` | "Formato de cabecera Authorization inválido. Se espera "Bearer TOKEN"." |
| El servidor no tiene ningún token configurado | 401 | `uda_unauthorized` | "El token de autenticación no ha sido configurado en el servidor." |
| El token enviado no coincide con el configurado | 401 | `uda_unauthorized` | "Token inválido." |

La comparación del token se hace en tiempo constante (`hash_equals()`). Forma exacta de una respuesta 401 (formato estándar de error de la REST API de WordPress):

```json
{
  "code": "uda_unauthorized",
  "message": "Token inválido.",
  "data": { "status": 401, "success": false }
}
```

## 3. Headers requeridos

| Header | Valor | Obligatorio |
|---|---|---|
| `Authorization` | `Bearer TU_TOKEN_AQUI` | Sí |
| `Content-Type` | `application/json` | Sí |

## 4. Parámetros (body JSON)

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `user_id` | integer | No\\* | ID numérico del usuario de WordPress. |
| `email` | string | No\\* | Correo electrónico exacto del usuario. |

\\* Debe enviarse **al menos uno** de los dos. Si se envían ambos, `user_id` tiene prioridad y `email` se ignora por completo.

El endpoint solo permite consultar UN usuario por petición, por ID o correo EXACTOS — nunca acepta listados, comodines ni búsquedas parciales. No existe forma de listar/enumerar usuarios con esta API.

### Notas de validación

- Si no se envía ni `user_id` ni `email`: error 400.
- Si se envía `email` (y no `user_id`) con formato inválido: error 400.
- WordPress valida el tipo de cada parámetro antes de llegar al plugin: si `user_id` no es numérico o `email` no es un string, la API puede responder con el error genérico de WordPress `rest_invalid_param` (HTTP 400) antes de que se ejecute la lógica del plugin.

## 5. Respuesta exitosa (200)

```json
{
  "success": true,
  "user": { }
}
```

### 5.1 Estructura completa de `user`

| Campo | Tipo | Descripción |
|---|---|---|
| `id` | integer | ID del usuario en WordPress. |
| `email` | string | Correo electrónico. |
| `username` | string | `user_login`. |
| `first_name` | string | Puede ser cadena vacía si no está definido. |
| `last_name` | string | Puede ser cadena vacía si no está definido. |
| `full_name` | string | `first_name + " " + last_name`; si ambos están vacíos, cae a `display_name` y luego a `username`. |
| `roles` | string[] | Roles de WordPress del usuario (ej. `["subscriber"]`). |
| `registered_at` | string | Fecha de registro (`user_registered`), formato `YYYY-MM-DD HH:MM:SS`. |
| `profile.completed` | boolean | `true` si el usuario tiene, sin vacíos, los 7 campos de perfil que exige el ecosistema WMS Latam. Esos 7 campos NO se exponen individualmente, solo este booleano. |
| `company` | object \\| null | `null` si el usuario no tiene ninguna empresa/área asignada. Ver 5.2. |
| `area` | object \\| null | `null` en el mismo caso que `company`. Ver 5.2. |
| `courses` | array | Cursos de LearnDash asignados. `[]` si LearnDash no está activo o el usuario no tiene cursos. Ver 5.3. |
| `test` | object | Estado y resultados del test "Sentido Vital". Ver 5.4. |

### 5.2 `company` y `area`

Se resuelven a partir de la membresía más reciente del usuario. Si no tiene ninguna, ambos campos son `null`.

`company` (objeto, o `null`):

| Campo | Tipo |
|---|---|
| `id` | integer |
| `name` | string |
| `email` | string |

Nota: `company` puede ser `null` aunque `area` no lo sea, si el área existe pero su `grupo_id` no corresponde a ningún usuario con rol `group_admin`.

`area` (objeto, o `null`):

| Campo | Tipo |
|---|---|
| `id` | integer |
| `name` | string |
| `quota` | integer |
| `status` | string |
| `expires_at` | string (fecha) |
| `membership.status` | string |
| `membership.expires_at` | string (fecha) |

### 5.3 `courses` (array)

Cada elemento:

| Campo | Tipo |
|---|---|
| `id` | integer |
| `title` | string |
| `status` | string — valor devuelto directamente por `learndash_course_status()` de LearnDash (ej. `"in_progress"`, `"completed"`, `"not_started"`; el valor exacto depende de la versión/configuración de LearnDash instalada). |
| `progress_percentage` | integer (0–100) |
| `completed_steps` | integer |
| `total_steps` | integer |
| `completed` | boolean — `true` si `progress_percentage >= 100`. |

### 5.4 `test`

Si el usuario NO ha completado el test:

```json
{ "completed": false, "question_test_ids": null, "results": null }
```

Si SÍ lo completó:

| Campo | Tipo | Descripción |
|---|---|---|
| `completed` | boolean | `true`. |
| `question_test_ids` | array \\| string | Respuestas crudas: array de `{question, answer, value}` (17 elementos). En un caso muy raro de dato corrupto no decodificable como JSON, se devuelve la cadena cruda tal cual. |
| `results` | object \\| null | `null` únicamente si `question_test_ids` no pudo decodificarse como array válido. En cualquier otro caso, siempre trae el cálculo. |

`results` (cuando no es `null`):

| Campo | Tipo |
|---|---|
| `average` | number — `suma_de_valores / 17`, redondeado a 2 decimales. |
| `scale.min` / `scale.max` / `scale.question_count` | `0` / `3` / `17` |
| `classification.key` | string — una de: `busqueda-sentido`, `medio-sentido`, `alto-sentido`, `plenitud-sentido`. |
| `classification.label` / `.description` | string |
| `classification.range.min` / `.max` | number |
| `levels` | array con los 4 niveles completos (mismo shape que `classification`, ordenados de menor a mayor), útil para mostrar la escala completa sin duplicarla. |

Umbrales exactos (promedio ≥ mínimo indicado):

| `key` | `label` | rango |
|---|---|---|
| `plenitud-sentido` | Plenitud de sentido | 2.65 – 3.0 |
| `alto-sentido` | Alto sentido vital | 2.35 – 2.64 |
| `medio-sentido` | Medio sentido vital | 2.0 – 2.34 |
| `busqueda-sentido` | Búsqueda de sentido vital | 0.0 – 1.99 |

## 6. Códigos de error

| HTTP | Origen | Respuesta |
|---|---|---|
| 400 | Plugin | `{"success": false, "message": "Debes enviar \\"user_id\\" o \\"email\\"."}` — no se envió ninguno de los dos. |
| 400 | Plugin | `{"success": false, "message": "El formato del correo electrónico no es válido."}` — se envió `email` (sin `user_id`) con formato inválido. |
| 400 | WordPress (core) | `{"code": "rest_invalid_param", ...}` — `user_id` o `email` con un tipo incompatible con el esquema declarado. |
| 401 | Plugin (auth) | Ver tabla de la sección 2. |
| 404 | Plugin | `{"success": false, "message": "Usuario no encontrado."}` — no existe ningún usuario con ese `user_id`/`email`. |
| 200 | Plugin | Éxito, con el objeto `user` completo. |

## 7. Ejemplos completos

### 7.1 Consulta por email — éxito

**Petición:**

```
POST {$endpoint_alt}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{"email": "usuario@ejemplo.com"}
```

**Respuesta (200):**

```json
{
  "success": true,
  "user": {
    "id": 123,
    "email": "usuario@ejemplo.com",
    "username": "usuario",
    "first_name": "Juan",
    "last_name": "Pérez",
    "full_name": "Juan Pérez",
    "roles": ["subscriber"],
    "registered_at": "2026-01-01 10:00:00",
    "profile": { "completed": true },
    "company": { "id": 10, "name": "Empresa Ejemplo", "email": "contacto@empresa-ejemplo.com" },
    "area": {
      "id": 5,
      "name": "Recursos Humanos",
      "quota": 20,
      "status": "Activado",
      "expires_at": "2026-12-31",
      "membership": { "status": "ACTIVO", "expires_at": "31-12-2026" }
    },
    "courses": [
      { "id": 120, "title": "Curso de ejemplo", "status": "in_progress", "progress_percentage": 65, "completed_steps": 13, "total_steps": 20, "completed": false }
    ],
    "test": {
      "completed": true,
      "question_test_ids": [{ "question": 1, "answer": 2, "value": 1 }],
      "results": {
        "average": 2.12,
        "scale": { "min": 0, "max": 3, "question_count": 17 },
        "classification": {
          "key": "medio-sentido",
          "label": "Medio sentido vital",
          "description": "Personas que entienden algunas de las razones por las que actúan en su vida, pero en ciertas áreas pueden experimentar cierta desmotivación.",
          "range": { "min": 2, "max": 2.34 }
        },
        "levels": [
          { "key": "busqueda-sentido", "label": "Búsqueda de sentido vital", "description": "Personas que en algunas ocasiones experimentan su vida sin sentido ni propósito.", "range": { "min": 0, "max": 1.99 } },
          { "key": "medio-sentido", "label": "Medio sentido vital", "description": "Personas que entienden algunas de las razones por las que actúan en su vida, pero en ciertas áreas pueden experimentar cierta desmotivación.", "range": { "min": 2, "max": 2.34 } },
          { "key": "alto-sentido", "label": "Alto sentido vital", "description": "Personas que generalmente tienen claras sus metas y las razones por las que actúan en su vida, aunque en ocasiones se alejan de su rumbo claro.", "range": { "min": 2.35, "max": 2.64 } },
          { "key": "plenitud-sentido", "label": "Plenitud de sentido", "description": "Personas que experimentan su vida llena de significado.", "range": { "min": 2.65, "max": 3 } }
        ]
      }
    }
  }
}
```

### 7.2 Consulta por user_id — usuario sin empresa ni test

**Petición:**

```
POST {$endpoint_alt}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{"user_id": 456}
```

**Respuesta (200):**

```json
{
  "success": true,
  "user": {
    "id": 456,
    "email": "otro@ejemplo.com",
    "username": "otro",
    "first_name": "",
    "last_name": "",
    "full_name": "otro",
    "roles": ["subscriber"],
    "registered_at": "2026-03-10 08:22:00",
    "profile": { "completed": false },
    "company": null,
    "area": null,
    "courses": [],
    "test": { "completed": false, "question_test_ids": null, "results": null }
  }
}
```

### 7.3 Error — falta user_id y email (400)

**Petición:**

```
POST {$endpoint_alt}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{}
```

**Respuesta (400):**

```json
{ "success": false, "message": "Debes enviar \\"user_id\\" o \\"email\\"." }
```

### 7.4 Error — usuario no encontrado (404)

**Petición:**

```
POST {$endpoint_alt}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{"email": "no-existe@ejemplo.com"}
```

**Respuesta (404):**

```json
{ "success": false, "message": "Usuario no encontrado." }
```

### 7.5 Error — token inválido (401)

**Petición:**

```
POST {$endpoint_alt}
Authorization: Bearer token-incorrecto
Content-Type: application/json

{"user_id": 123}
```

**Respuesta (401):**

```json
{
  "code": "uda_unauthorized",
  "message": "Token inválido.",
  "data": { "status": 401, "success": false }
}
```

---
Generado automáticamente desde el código del plugin User Data API (Octágono WMS) v{$this->get_plugin_version()}.
MD_USUARIO;
	}

	/**
	 * Genera la documentación técnica en Markdown del endpoint de creación
	 * de empresas (`/company`), con el mismo criterio que
	 * `build_docs_markdown_usuario()`: todo el contenido sale del
	 * comportamiento real de `UDA_Company_Api`, `UDA_Company` y `UDA_Area`.
	 *
	 * @param string $endpoint URL completa de la ruta `/company`.
	 * @return string Documento en formato Markdown.
	 */
	private function build_docs_markdown_empresa( $endpoint ) {
		return <<<MD_EMPRESA
# User Data API (Octágono WMS) — Crear empresa

> Documentación técnica generada a partir del código real del plugin (v{$this->get_plugin_version()}). Pensada para que un agente de IA integre este endpoint de forma autónoma, sin acceso al código fuente.

## 1. Endpoint

| | |
|---|---|
| **URL** | `{$endpoint}` |
| **Método HTTP** | `POST` |
| **Formato de body** | JSON |

Crea una empresa (un usuario de WordPress con rol `group_admin`) y, opcionalmente, sus áreas, como una sola operación.

## 2. Autenticación

Mismo Bearer Token que el endpoint de consulta de usuario (`/user` / `/lookup`) — es un único token para toda la API del plugin.

```
Authorization: Bearer TU_TOKEN_AQUI
```

La validación del token ocurre antes de cualquier lógica de negocio. Los mismos 4 casos de error 401 del endpoint de consulta de usuario aplican aquí sin cambios (cabecera ausente, formato inválido, token no configurado, token incorrecto), con la misma forma de respuesta:

```json
{
  "code": "uda_unauthorized",
  "message": "Token inválido.",
  "data": { "status": 401, "success": false }
}
```

## 3. Headers requeridos

| Header | Valor | Obligatorio |
|---|---|---|
| `Authorization` | `Bearer TU_TOKEN_AQUI` | Sí |
| `Content-Type` | `application/json` | Sí |

## 4. Parámetros (body JSON)

| Parámetro | Tipo | Obligatorio | Valor por defecto si se omite / llega vacío o `null` |
|---|---|---|---|
| `nombre_empresa` | string | **Sí** | — (único campo verdaderamente obligatorio) |
| `user_email` | string | No | Se autogenera: `admin.(slug-del-nombre-de-empresa)@wmslatam.com` |
| `nombre_encargado` | string | No | `"José Martínez"` |
| `contacto` | string | No | Teléfono aleatorio de 10 dígitos, formato celular colombiano (empieza en "3") |
| `ocupacion` | string | No | `"Administrador WMS"` |
| `areas` | array de objetos | No | Se crea automáticamente UN área: `{"nombre": "Área demo", "cupos": 2, "fecha_expiracion": hoy + 6 meses}` |

### Notas importantes

- **`nombre_empresa` debe ser único** (comparación sin distinguir mayúsculas/minúsculas). Si ya existe una empresa con ese nombre exacto, la petición se rechaza con 409 sin crear nada.
- **`user_email`, si se envía, debe ser único** en todo el sitio (no solo entre empresas). Si el correo ya existe (de cualquier usuario), se rechaza con 409.
- `user_email`, `nombre_encargado`, `contacto` y `ocupacion` NO tienen `type` declarado a propósito en el esquema REST: así se acepta tanto `""` como `null` explícito sin que WordPress los rechace antes de que el plugin aplique su valor por defecto.
- `nombre_empresa` sí tiene `type: string` declarado: si se envía con un tipo incompatible (ej. un número), WordPress puede responder con su error genérico `rest_invalid_param` (400) antes de llegar a la lógica del plugin.

### 4.1 `areas` (opcional)

Array de objetos. Cada uno:

| Campo | Tipo | Obligatorio | Valor por defecto |
|---|---|---|---|
| `nombre` | string | **Sí** | — |
| `cupos` | integer ≥ 1 | **Sí** | — |
| `fecha_expiracion` | string `YYYY-MM-DD` | No | Hoy + 6 meses. No puede ser una fecha anterior a hoy. |

Reglas:

- Si **cualquier** área del arreglo viene mal formada (sin `nombre`, `cupos` inválido, o `fecha_expiracion` inválida/pasada), la petición **completa** se rechaza con 400 y **no se crea nada** (ni la empresa ni ninguna área) — el arreglo se valida entero antes de tocar la base de datos.
- Si `areas` se omite, llega `[]`, `""` o `null`: se crea automáticamente UN área por defecto ("Área demo", 2 cupos). Ninguna empresa creada por esta API queda nunca sin áreas.
- Este sitio no maneja licencias ni "código de área": si se envían `codigo` o `licencia_id` dentro de un área, se aceptan sin error pero **no se guardan en ningún lado**.

### 4.2 Autogeneración de `user_email`

Si se omite, si es `""` o si es `null`:

1. Se genera un slug a partir de `nombre_empresa`: minúsculas, sin acentos, sin la palabra "demo" (como palabra completa, en cualquier posición), sin ningún carácter fuera de `[a-z0-9]`, truncado a 40 caracteres.
2. El correo final es `admin.(slug)@wmslatam.com`.
3. Si ese correo ya existe, se agregan sufijos numéricos (`admin.(slug)2@wmslatam.com`, `admin.(slug)3@wmslatam.com`, …) hasta encontrar uno libre; en último caso, un sufijo aleatorio.

## 5. Respuesta exitosa (201)

```json
{
  "success": true,
  "message": "La empresa se ha registrado correctamente.",
  "empresa": {
    "user_id": 123,
    "nombre_empresa": "Empresa de ejemplo",
    "email": "empresa@ejemplo.com",
    "password": "xxxxxxxx",
    "rol": "company"
  },
  "areas": [ ],
  "defaults_aplicados": []
}
```

| Campo | Tipo | Descripción |
|---|---|---|
| `empresa.user_id` | integer | ID de WordPress del usuario-empresa creado. |
| `empresa.nombre_empresa` | string | El nombre enviado (eco de la petición). |
| `empresa.email` | string | Correo FINAL usado (el enviado, o el autogenerado). |
| `empresa.password` | string | **Contraseña generada en texto plano.** Este endpoint no envía correo de bienvenida ni sincroniza con otro sitio: es el único canal para entregarla. Quien consuma la API es responsable de transmitirla de forma segura (HTTPS) y no guardarla en logs. |
| `empresa.rol` | string | Siempre `"company"` (etiqueta legible; el rol real de WordPress es `group_admin`). |
| `areas` | array | Un resultado por cada área enviada, o por el área por defecto si no se envió ninguna. Nunca es `[]`. |
| `defaults_aplicados` | string[] | Nombres de los campos opcionales que llegaron vacíos/`null`/ausentes y se completaron automáticamente. Valores posibles: `"email"`, `"nombre_encargado"`, `"contacto"`, `"ocupacion"`, `"areas"`. |

### 5.1 Cada elemento de `areas`

Éxito:

```json
{ "id": 45, "nombre": "Ventas", "cupos": 20, "fecha_expiracion": "2027-03-23", "success": true }
```

Fallo puntual (la empresa ya quedó creada; solo esa área específica falló al insertarse):

```json
{ "nombre": "Ventas", "success": false, "message": "Ocurrió un error al crear el área en la base de datos." }
```

## 6. Códigos de error

| HTTP | `code` (WP_Error) | `message` |
|---|---|---|
| 400 | `nombre_requerido` | "El nombre de la empresa es obligatorio." |
| 409 | `empresa_existente` | "Ya existe una empresa registrada con ese nombre." |
| 400 | `correo_invalido` | "El correo electrónico no tiene un formato válido." |
| 409 | `usuario_existente` | "Ya existe un usuario registrado con ese correo electrónico." |
| 400 | `areas_invalidas` | ""areas" debe ser un arreglo de objetos." |
| 400 | `area_invalida` | "El área en la posición N no es un objeto válido." |
| 400 | `area_nombre_requerido` | "El área en la posición N debe tener "nombre"." |
| 400 | `area_cupos_invalido` | "El área "X" (posición N) debe tener "cupos" como un número entero mayor o igual a 1." |
| 400 | `area_fecha_invalida` | "El área "X" (posición N) tiene un "fecha_expiracion" inválido." |
| 400 | `area_fecha_pasada` | "El área "X" (posición N) tiene un "fecha_expiracion" anterior a hoy." |
| 401 | `uda_unauthorized` | Ver sección 2. |

Todos los errores 400/409 de esta lista tienen esta forma exacta:

```json
{ "success": false, "message": "..." }
```

Nota: solo `empresa_existente` y `usuario_existente` responden con HTTP 409; el resto de errores de negocio de este endpoint responde con HTTP 400.

## 7. Ejemplos completos

### 7.1 Creación mínima (solo nombre_empresa) — éxito

**Petición:**

```
POST {$endpoint}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{"nombre_empresa": "Acme Colombia"}
```

**Respuesta (201):**

```json
{
  "success": true,
  "message": "La empresa se ha registrado correctamente.",
  "empresa": {
    "user_id": 501,
    "nombre_empresa": "Acme Colombia",
    "email": "admin.acmecolombia@wmslatam.com",
    "password": "kx92mQtz4L1r",
    "rol": "company"
  },
  "areas": [
    { "id": 60, "nombre": "Área demo", "cupos": 2, "fecha_expiracion": "2027-03-24", "success": true }
  ],
  "defaults_aplicados": ["email", "nombre_encargado", "contacto", "ocupacion", "areas"]
}
```

### 7.2 Creación completa, con áreas explícitas

**Petición:**

```
POST {$endpoint}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{
  "nombre_empresa": "Empresa de ejemplo",
  "user_email": "empresa@ejemplo.com",
  "nombre_encargado": "Nombre Apellido",
  "contacto": "3001234567",
  "ocupacion": "Gerente",
  "areas": [
    { "nombre": "Ventas", "cupos": 20 },
    { "nombre": "Recursos Humanos", "cupos": 5, "fecha_expiracion": "2027-03-23" }
  ]
}
```

**Respuesta (201):**

```json
{
  "success": true,
  "message": "La empresa se ha registrado correctamente.",
  "empresa": {
    "user_id": 502,
    "nombre_empresa": "Empresa de ejemplo",
    "email": "empresa@ejemplo.com",
    "password": "qz8Fh2Nprs1a",
    "rol": "company"
  },
  "areas": [
    { "id": 61, "nombre": "Ventas", "cupos": 20, "fecha_expiracion": "2027-03-24", "success": true },
    { "id": 62, "nombre": "Recursos Humanos", "cupos": 5, "fecha_expiracion": "2027-03-23", "success": true }
  ],
  "defaults_aplicados": []
}
```

### 7.3 Error — nombre_empresa ya existe (409)

**Petición:**

```
POST {$endpoint}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{"nombre_empresa": "Acme Colombia"}
```

**Respuesta (409):**

```json
{ "success": false, "message": "Ya existe una empresa registrada con ese nombre." }
```

### 7.4 Error — área con cupos inválido (400, no se crea nada)

**Petición:**

```
POST {$endpoint}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{
  "nombre_empresa": "Otra Empresa",
  "areas": [ { "nombre": "Ventas", "cupos": 0 } ]
}
```

**Respuesta (400):**

```json
{ "success": false, "message": "El área \\"Ventas\\" (posición 1) debe tener \\"cupos\\" como un número entero mayor o igual a 1." }
```

### 7.5 Error — falta nombre_empresa (400)

**Petición:**

```
POST {$endpoint}
Authorization: Bearer TU_TOKEN_AQUI
Content-Type: application/json

{}
```

**Respuesta (400):**

```json
{ "success": false, "message": "El nombre de la empresa es obligatorio." }
```

---
Generado automáticamente desde el código del plugin User Data API (Octágono WMS) v{$this->get_plugin_version()}.
MD_EMPRESA;
	}

	/**
	 * Versión del plugin, usada al pie de la documentación descargable
	 * para que quede claro contra qué versión del código se generó.
	 *
	 * @return string
	 */
	private function get_plugin_version() {
		return defined( 'UDA_VERSION' ) ? UDA_VERSION : '';
	}

	/**
	 * Renderiza la página de administración del plugin.
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos suficientes para acceder a esta página.', 'user-data-api' ) );
		}

		$token           = $this->settings->get_token();
		$endpoint        = rest_url( UDA_Api::NAMESPACE . UDA_Api::ROUTE );
		$endpoint_alt    = rest_url( UDA_Api::NAMESPACE . UDA_Api::ROUTE_ALT );
		$token_shown     = $token ? $token : 'TU_TOKEN';
		$token_configured = '' !== $token;
		$docs_markdown   = $this->build_docs_markdown_usuario( $endpoint, $endpoint_alt );
		?>
		<div class="wrap uda-wrap wms-user-api-admin">

			<header class="uda-header">
				<div class="uda-header-brand">
					<div>
						<div class="uda-header-eyebrow"><?php esc_html_e( 'Octágono WMS B2B', 'user-data-api' ); ?></div>
						<h1 class="uda-header-title"><?php esc_html_e( 'User Data API', 'user-data-api' ); ?></h1>
						<p class="uda-header-subtitle">
							<?php esc_html_e( 'Endpoint REST protegido con Bearer Token para consultar el perfil completo de un usuario: empresa, área, cursos de LearnDash y resultados del test.', 'user-data-api' ); ?>
						</p>
					</div>
				</div>
				<div class="uda-header-actions">
					<span class="uda-badge <?php echo $token_configured ? 'uda-badge--success' : 'uda-badge--warning'; ?>">
						<?php echo $token_configured ? esc_html__( 'Token configurado', 'user-data-api' ) : esc_html__( 'Token sin configurar', 'user-data-api' ); ?>
					</span>
					<button
						type="button"
						class="button uda-btn-header-doc uda-download-doc"
						data-doc-target="uda-doc-md-usuario"
						data-filename="user-data-api-consultar-usuario.md"
					>
						<?php esc_html_e( 'Descargar documentación (.md)', 'user-data-api' ); ?>
					</button>
				</div>
			</header>

			<?php
			/*
			 * El contenido se embebe en un <textarea> oculto, no en un
			 * <script type="text/plain">: el modelo de contenido de
			 * <script> es "raw text" y el navegador NO decodifica
			 * entidades HTML dentro de él, así que el JS recuperaría
			 * literalmente "&quot;", "&gt;", etc. en vez del Markdown
			 * original. <textarea> sí es "texto crudo escapable": decodifica
			 * las entidades de esc_textarea() al leer su valor, sin
			 * interpretar ninguna etiqueta — exactamente lo que se necesita
			 * para transportar el documento tal cual.
			 */
			?>
			<textarea id="uda-doc-md-usuario" class="uda-doc-source" hidden readonly aria-hidden="true" tabindex="-1"><?php echo esc_textarea( $docs_markdown ); ?></textarea>

			<div class="uda-grid">
				<div class="uda-card">
					<h2><?php esc_html_e( 'Configuración de la API', 'user-data-api' ); ?></h2>
					<p class="uda-card-subtitle">
						<?php esc_html_e( 'Ruta del endpoint y token Bearer requeridos para autenticar cada petición.', 'user-data-api' ); ?>
					</p>

					<div class="uda-meta-row">
						<span class="uda-meta-chip">
							<strong><?php esc_html_e( 'Endpoint', 'user-data-api' ); ?>:</strong>
							<code><?php echo esc_html( $endpoint ); ?></code>
						</span>
						<span class="uda-meta-chip">
							<strong><?php esc_html_e( 'Alterno', 'user-data-api' ); ?>:</strong>
							<code><?php echo esc_html( $endpoint_alt ); ?></code>
						</span>
						<span class="uda-meta-chip">
							<strong><?php esc_html_e( 'Método', 'user-data-api' ); ?>:</strong>
							<code>POST</code>
						</span>
					</div>

					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Ambas rutas son idénticas en comportamiento. Usa la alterna ("/lookup") si tu firewall (Wordfence u otro) bloquea peticiones a rutas REST que terminan en "/user" por su regla anti-enumeración de usuarios.', 'user-data-api' ); ?>
					</p>

					<form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>">
						<?php settings_fields( UDA_Settings::OPTION_GROUP ); ?>

						<label for="uda-token-field" class="uda-filter-label" style="display:block;margin-bottom:6px;">
							<?php esc_html_e( 'Token de autenticación', 'user-data-api' ); ?>
						</label>

						<div class="uda-token-row">
							<input
								type="text"
								id="uda-token-field"
								name="<?php echo esc_attr( UDA_Settings::OPTION_NAME ); ?>"
								value="<?php echo esc_attr( $token ); ?>"
								autocomplete="off"
								spellcheck="false"
							/>
							<button type="button" class="button uda-btn-icon" id="uda-copy-token">
								<?php esc_html_e( 'Copiar', 'user-data-api' ); ?>
							</button>
							<button type="button" class="button uda-btn-accent" id="uda-generate-token">
								<?php esc_html_e( 'Generar token seguro', 'user-data-api' ); ?>
							</button>
						</div>

						<p class="description">
							<?php esc_html_e( 'El token es fijo: se mantiene igual entre peticiones, recargas de página y reactivaciones del plugin. Solo cambia si pulsas "Generar token seguro" (se guarda de inmediato) o si editas el campo a mano y pulsas "Guardar cambios". Envíalo en la cabecera "Authorization: Bearer TOKEN"; nunca se muestra en el sitio público. Si el campo queda vacío, la API rechazará todas las peticiones.', 'user-data-api' ); ?>
						</p>

						<?php submit_button( __( 'Guardar cambios', 'user-data-api' ), 'button uda-btn-primary' ); ?>
					</form>
				</div>

				<div class="uda-card">
					<h2><?php esc_html_e( 'Ejemplo de petición (cURL)', 'user-data-api' ); ?></h2>
					<p class="uda-card-subtitle">
						<?php esc_html_e( 'Lista para copiar y probar en tu terminal.', 'user-data-api' ); ?>
					</p>
					<div class="uda-code-block" style="margin-bottom: var(--wms-space-5);">
						<pre class="uda-code" id="uda-curl-example"><?php
						echo esc_html(
							sprintf(
								"curl -X POST '%s' \\\n  -H 'Authorization: Bearer %s' \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"email\":\"usuario@ejemplo.com\"}'",
								$endpoint_alt,
								$token_shown
							)
						);
						?></pre>
						<button type="button" class="uda-copy-btn" data-copy-target="uda-curl-example">
							<?php esc_html_e( 'Copiar', 'user-data-api' ); ?>
						</button>
					</div>
					<p class="uda-card-subtitle" style="margin-top:-8px;">
						<?php esc_html_e( 'Este ejemplo usa la ruta alterna (recomendada). La ruta original sigue funcionando igual si ya la tienes integrada.', 'user-data-api' ); ?>
					</p>

					<h2><?php esc_html_e( 'JSON esperado (body)', 'user-data-api' ); ?></h2>
					<pre class="uda-code">{
  "email": "usuario@ejemplo.com"
}

<?php esc_html_e( '// o bien, por ID:', 'user-data-api' ); ?>

{
  "user_id": 123
}</pre>
				</div>
			</div>

			<div class="uda-card">
				<h2><?php esc_html_e( 'Previsualización de usuario', 'user-data-api' ); ?></h2>
				<p class="uda-card-subtitle">
					<?php esc_html_e( 'Filtra por rol y por estado del test, luego busca y selecciona un usuario para previsualizar exactamente lo que devolvería la API, sin necesidad de Postman. Usa la misma función interna que el endpoint real.', 'user-data-api' ); ?>
				</p>

				<div class="uda-preview-filters">
					<label for="uda-role-filter">
						<span class="uda-filter-label"><?php esc_html_e( 'Rol de usuario', 'user-data-api' ); ?></span>
						<select id="uda-role-filter">
							<option value=""><?php esc_html_e( 'Todos los roles', 'user-data-api' ); ?></option>
							<?php foreach ( wp_roles()->get_names() as $role_slug => $role_label ) : ?>
								<option value="<?php echo esc_attr( $role_slug ); ?>"><?php echo esc_html( translate_user_role( $role_label ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label for="uda-test-filter">
						<span class="uda-filter-label"><?php esc_html_e( 'Estado del test', 'user-data-api' ); ?></span>
						<select id="uda-test-filter">
							<option value=""><?php esc_html_e( 'Todos', 'user-data-api' ); ?></option>
							<option value="con_test"><?php esc_html_e( 'Realizó el test', 'user-data-api' ); ?></option>
							<option value="sin_test"><?php esc_html_e( 'No ha realizado el test', 'user-data-api' ); ?></option>
						</select>
					</label>
				</div>

				<div class="uda-preview-controls">
					<input
						type="text"
						id="uda-user-search"
						placeholder="<?php esc_attr_e( 'Buscar por nombre, correo o usuario…', 'user-data-api' ); ?>"
					/>
					<select id="uda-user-select">
						<option value=""><?php esc_html_e( '— Selecciona un usuario —', 'user-data-api' ); ?></option>
					</select>
					<button type="button" class="button uda-btn-primary" id="uda-preview-btn">
						<?php esc_html_e( 'Previsualizar datos', 'user-data-api' ); ?>
					</button>
				</div>

				<div id="uda-preview-status" class="uda-preview-status" aria-live="polite"></div>

				<div id="uda-preview-result" class="uda-result" hidden>
					<div class="uda-result-header">
						<div>
							<p class="uda-result-name" id="uda-result-name"></p>
							<p class="uda-result-email" id="uda-result-email"></p>
						</div>
						<div class="uda-result-badges" id="uda-result-badges"></div>
					</div>

					<div class="uda-info-grid" id="uda-result-info"></div>

					<h2 style="margin-top: var(--wms-space-2);"><?php esc_html_e( 'Cursos asignados', 'user-data-api' ); ?></h2>
					<div class="uda-courses" id="uda-result-courses"></div>
				</div>

				<h2 style="margin-top: var(--wms-space-5);"><?php esc_html_e( 'Respuesta de la API', 'user-data-api' ); ?></h2>
				<div class="uda-code-block">
					<pre id="uda-preview-output" class="uda-code uda-preview-output"></pre>
					<button type="button" class="uda-copy-btn" id="uda-copy-json" data-copy-target="uda-preview-output">
						<?php esc_html_e( 'Copiar JSON', 'user-data-api' ); ?>
					</button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Renderiza la página de administración "API Crear empresa": documenta
	 * el endpoint `POST /wp-json/user-data-api/v1/company` (protegido con
	 * el mismo Bearer Token que el resto de la API) e incluye una
	 * herramienta de prueba que crea la empresa directamente desde el
	 * admin, sin necesidad de Postman, reutilizando internamente la misma
	 * lógica que el botón "Crear Empresa" del plugin "Administrar Empresa
	 * Octágono".
	 *
	 * @return void
	 */
	public function render_company_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos suficientes para acceder a esta página.', 'user-data-api' ) );
		}

		$token            = $this->settings->get_token();
		$endpoint         = rest_url( UDA_Company_Api::NAMESPACE . UDA_Company_Api::ROUTE );
		$token_shown      = $token ? $token : 'TU_TOKEN';
		$token_configured = '' !== $token;
		$docs_markdown    = $this->build_docs_markdown_empresa( $endpoint );
		?>
		<div class="wrap uda-wrap wms-user-api-admin">

			<header class="uda-header">
				<div class="uda-header-brand">
					<div>
						<div class="uda-header-eyebrow"><?php esc_html_e( 'Octágono WMS B2B', 'user-data-api' ); ?></div>
						<h1 class="uda-header-title"><?php esc_html_e( 'API Crear empresa', 'user-data-api' ); ?></h1>
						<p class="uda-header-subtitle">
							<?php esc_html_e( 'Endpoint REST protegido con Bearer Token para crear una empresa (usuario con rol "group_admin"): mismos campos que el botón "Crear Empresa" del panel de Administrar Empresa Octágono.', 'user-data-api' ); ?>
						</p>
					</div>
				</div>
				<div class="uda-header-actions">
					<span class="uda-badge <?php echo $token_configured ? 'uda-badge--success' : 'uda-badge--warning'; ?>">
						<?php echo $token_configured ? esc_html__( 'Token configurado', 'user-data-api' ) : esc_html__( 'Token sin configurar', 'user-data-api' ); ?>
					</span>
					<button
						type="button"
						class="button uda-btn-header-doc uda-download-doc"
						data-doc-target="uda-doc-md-empresa"
						data-filename="user-data-api-crear-empresa.md"
					>
						<?php esc_html_e( 'Descargar documentación (.md)', 'user-data-api' ); ?>
					</button>
				</div>
			</header>

			<textarea id="uda-doc-md-empresa" class="uda-doc-source" hidden readonly aria-hidden="true" tabindex="-1"><?php echo esc_textarea( $docs_markdown ); ?></textarea>

			<div class="uda-grid">
				<div class="uda-card">
					<h2><?php esc_html_e( 'Configuración de la API', 'user-data-api' ); ?></h2>
					<p class="uda-card-subtitle">
						<?php esc_html_e( 'Ruta del endpoint y token Bearer requeridos para autenticar cada petición.', 'user-data-api' ); ?>
					</p>

					<div class="uda-meta-row">
						<span class="uda-meta-chip">
							<strong><?php esc_html_e( 'Endpoint', 'user-data-api' ); ?>:</strong>
							<code><?php echo esc_html( $endpoint ); ?></code>
						</span>
						<span class="uda-meta-chip">
							<strong><?php esc_html_e( 'Método', 'user-data-api' ); ?>:</strong>
							<code>POST</code>
						</span>
					</div>

					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Usa el mismo token Bearer configurado en "API info usuario" (es un único token para toda la API de este plugin). Si aún no lo has configurado o quieres regenerarlo, hazlo desde esa página.', 'user-data-api' ); ?>
					</p>

					<label for="uda-company-token-field" class="uda-filter-label" style="display:block;margin-bottom:6px;">
						<?php esc_html_e( 'Token de autenticación actual', 'user-data-api' ); ?>
					</label>
					<div class="uda-token-row">
						<input
							type="text"
							id="uda-company-token-field"
							value="<?php echo esc_attr( $token_shown ); ?>"
							readonly="readonly"
							autocomplete="off"
							spellcheck="false"
						/>
						<button type="button" class="button uda-btn-icon" id="uda-copy-company-token">
							<?php esc_html_e( 'Copiar', 'user-data-api' ); ?>
						</button>
					</div>
				</div>

				<div class="uda-card">
					<h2><?php esc_html_e( 'Ejemplo de petición (cURL)', 'user-data-api' ); ?></h2>
					<p class="uda-card-subtitle">
						<?php esc_html_e( 'Lista para copiar y probar en tu terminal.', 'user-data-api' ); ?>
					</p>
					<div class="uda-code-block" style="margin-bottom: var(--wms-space-5);">
						<pre class="uda-code" id="uda-company-curl-example"><?php
						echo esc_html(
							sprintf(
								"curl -X POST '%s' \\\n  -H 'Authorization: Bearer %s' \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"user_email\":\"empresa@ejemplo.com\",\"nombre_empresa\":\"Empresa de ejemplo\",\"nombre_encargado\":\"Nombre Apellido\",\"contacto\":\"3001234567\",\"ocupacion\":\"Gerente\"}'",
								$endpoint,
								$token_shown
							)
						);
						?></pre>
						<button type="button" class="uda-copy-btn" data-copy-target="uda-company-curl-example">
							<?php esc_html_e( 'Copiar', 'user-data-api' ); ?>
						</button>
					</div>

					<h2><?php esc_html_e( 'JSON esperado (body)', 'user-data-api' ); ?></h2>
					<p class="uda-card-subtitle" style="margin-top:0;">
						<?php esc_html_e( 'Solo nombre_empresa es obligatorio. user_email, nombre_encargado, contacto, ocupacion y areas son opcionales.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'nombre_empresa debe ser único (sin distinguir mayúsculas/minúsculas): si ya existe una empresa con ese nombre, la petición se rechaza con 409, sin crear el usuario.', 'user-data-api' ); ?>
					</p>
					<pre class="uda-code">{
  "nombre_empresa": "Empresa de ejemplo",
  "user_email": "empresa@ejemplo.com",
  "nombre_encargado": "Nombre Apellido",
  "contacto": "3001234567",
  "ocupacion": "Gerente",
  "areas": [
    { "nombre": "Ventas", "cupos": 20 },
    { "nombre": "Recursos Humanos", "cupos": 5, "fecha_expiracion": "2027-03-23" }
  ]
}</pre>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Cada área de "areas" necesita "nombre" y "cupos" (entero >= 1); "fecha_expiracion" es opcional (formato AAAA-MM-DD, no puede ser anterior a hoy) y si se omite se usa hoy + 6 meses, igual que el campo precargado en el modal "Crear Área" de Administrar Empresa Octágono. Si CUALQUIER área viene mal formada, toda la petición se rechaza con 400 y no se crea ni la empresa ni ninguna área.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Si "areas" se omite, llega vacío o llega null (no se pidió ninguna área), se crea automáticamente UN área por defecto: "Área demo", 2 cupos, con fecha_expiracion = hoy + 6 meses.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Nota: este sitio no tiene tabla de licencias ni código de área (a diferencia de otros sitios del ecosistema WMS Latam). Si envías "codigo" o "licencia_id" dentro de un área, se aceptan sin error pero no se guardan en ningún lado.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Si omites user_email, lo envías vacío ("") o lo envías como null, se autogenera con el formato "admin.(slug-del-nombre-de-empresa)@wmslatam.com". El slug sale de nombre_empresa en minúsculas, sin acentos ni caracteres especiales/espacios, y sin la palabra "demo" (se ignora como palabra completa, en cualquier posición). Si tras limpiar el nombre no queda ningún carácter (ej. "Demo" o "¡¡¡!!!"), se usa un slug de respaldo aleatorio. Si el correo autogenerado ya existe, se agrega automáticamente un sufijo numérico.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Si omites nombre_encargado, lo envías vacío ("") o lo envías como null, se guarda "José Martínez" por defecto.', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Si omites contacto, lo envías vacío ("") o lo envías como null, se genera un número telefónico aleatorio de 10 dígitos (formato celular colombiano, empieza en "3").', 'user-data-api' ); ?>
					</p>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( 'Si omites ocupacion, la envías vacía ("") o la envías como null, se guarda "Administrador WMS" por defecto.', 'user-data-api' ); ?>
					</p>
					<h2><?php esc_html_e( 'Respuesta exitosa (201)', 'user-data-api' ); ?></h2>
					<pre class="uda-code">{
  "success": true,
  "message": "La empresa se ha registrado correctamente.",
  "empresa": {
    "user_id": 123,
    "nombre_empresa": "Empresa de ejemplo",
    "email": "empresa@ejemplo.com",
    "password": "xxxxxxxx",
    "rol": "company"
  },
  "areas": [
    { "id": 45, "nombre": "Ventas", "cupos": 20, "fecha_expiracion": "2027-03-23", "success": true }
  ],
  "defaults_aplicados": []
}</pre>
					<p class="description" style="margin-top:0;">
						<?php esc_html_e( '"password" es la contraseña generada, en texto plano: este endpoint no envía correo de bienvenida ni sincroniza con otro sitio, así que es la única forma de entregarla. Quien consuma la API es responsable de transmitirla de forma segura y no guardarla en logs. "areas" trae un resultado por cada área enviada, o el área por defecto "Área demo" si no se envió ninguna (nunca queda vacío); si alguna falla al insertarse ya con la empresa creada (caso muy raro), aparece con "success": false y "message" en vez de "id". "defaults_aplicados" lista qué campos opcionales llegaron vacíos/null/ausentes y se completaron automáticamente (valores posibles: email, nombre_encargado, contacto, ocupacion, areas).', 'user-data-api' ); ?>
					</p>
				</div>
			</div>

			<div class="uda-card">
				<h2><?php esc_html_e( 'Probar creación de empresa', 'user-data-api' ); ?></h2>
				<p class="uda-card-subtitle">
					<?php esc_html_e( 'Crea una empresa real directamente desde aquí, sin Postman, usando la misma función interna que el endpoint REST.', 'user-data-api' ); ?>
				</p>

				<div class="uda-preview-filters">
					<label for="uda-company-nombre">
						<span class="uda-filter-label"><?php esc_html_e( 'Nombre de la empresa *', 'user-data-api' ); ?></span>
						<input type="text" id="uda-company-nombre" />
					</label>

					<label for="uda-company-email">
						<span class="uda-filter-label"><?php esc_html_e( 'Correo electrónico (opcional — se autogenera si lo dejas vacío)', 'user-data-api' ); ?></span>
						<input type="email" id="uda-company-email" placeholder="admin.(nombre-empresa)@wmslatam.com" />
					</label>

					<label for="uda-company-encargado">
						<span class="uda-filter-label"><?php esc_html_e( 'Nombre del encargado (vacío = "José Martínez")', 'user-data-api' ); ?></span>
						<input type="text" id="uda-company-encargado" />
					</label>

					<label for="uda-company-contacto">
						<span class="uda-filter-label"><?php esc_html_e( 'Teléfono de contacto (vacío = número aleatorio)', 'user-data-api' ); ?></span>
						<input type="text" id="uda-company-contacto" />
					</label>

					<label for="uda-company-ocupacion">
						<span class="uda-filter-label"><?php esc_html_e( 'Ocupación (vacío = "Administrador WMS")', 'user-data-api' ); ?></span>
						<input type="text" id="uda-company-ocupacion" />
					</label>
				</div>

				<div class="uda-preview-filters">
					<label for="uda-company-areas" style="flex: 1 1 100%;">
						<span class="uda-filter-label"><?php esc_html_e( 'Áreas a crear (JSON opcional)', 'user-data-api' ); ?></span>
						<textarea id="uda-company-areas" rows="4" style="width:100%;font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;font-size:12.5px;" placeholder='[{"nombre":"Ventas","cupos":20}]'></textarea>
					</label>
				</div>

				<div class="uda-preview-controls">
					<button type="button" class="button uda-btn-primary" id="uda-company-create-btn">
						<?php esc_html_e( 'Crear empresa', 'user-data-api' ); ?>
					</button>
				</div>

				<div id="uda-company-status" class="uda-preview-status" aria-live="polite"></div>

				<div id="uda-company-result" class="uda-result" hidden>
					<div class="uda-info-grid" id="uda-company-result-info"></div>
				</div>

				<h2 style="margin-top: var(--wms-space-5);"><?php esc_html_e( 'Respuesta de la API', 'user-data-api' ); ?></h2>
				<div class="uda-code-block">
					<pre id="uda-company-output" class="uda-code uda-preview-output"></pre>
					<button type="button" class="uda-copy-btn" data-copy-target="uda-company-output">
						<?php esc_html_e( 'Copiar JSON', 'user-data-api' ); ?>
					</button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX: genera un token aleatorio y lo guarda de inmediato (no queda
	 * en un estado "a medio guardar": en cuanto se genera, ya es el
	 * token real y persistente de la API, sin depender de que además se
	 * pulse "Guardar cambios"). El token solo cambia cuando se pulsa
	 * este botón (o se edita el campo a mano y se guarda); nunca cambia
	 * solo, ni al recargar la página, ni al reactivar el plugin.
	 *
	 * @return void
	 */
	public function ajax_generate_token() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'No autorizado.', 'user-data-api' ) ), 403 );
		}

		$token = $this->settings->generate_token();

		update_option( UDA_Settings::OPTION_NAME, $this->settings->sanitize_token( $token ) );

		wp_send_json_success( array( 'token' => $token ) );
	}

	/**
	 * AJAX: busca usuarios por nombre, correo o usuario para poblar el
	 * selector de la herramienta de previsualización, con filtros
	 * opcionales por rol y por estado del test.
	 *
	 * @return void
	 */
	public function ajax_search_users() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'No autorizado.', 'user-data-api' ) ), 403 );
		}

		$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		$role = isset( $_POST['role'] ) ? sanitize_key( wp_unslash( $_POST['role'] ) ) : '';
		$test = isset( $_POST['test'] ) ? sanitize_key( wp_unslash( $_POST['test'] ) ) : '';

		// Solo se acepta un rol que realmente exista registrado en el sitio.
		if ( '' !== $role && ! array_key_exists( $role, wp_roles()->get_names() ) ) {
			$role = '';
		}

		if ( ! in_array( $test, array( 'con_test', 'sin_test' ), true ) ) {
			$test = '';
		}

		$test_clause = $this->build_test_meta_query_clause( $test );

		$base_args = array(
			'number'  => 20,
			'orderby' => 'display_name',
			'order'   => 'ASC',
			'fields'  => 'ID',
		);

		if ( '' !== $role ) {
			$base_args['role'] = $role;
		}

		if ( '' !== $term ) {
			$search_args                   = $base_args;
			$search_args['search']         = '*' . $term . '*';
			$search_args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );

			if ( $test_clause ) {
				$search_args['meta_query'] = array( $test_clause );
			}

			$name_clause = array(
				'relation' => 'OR',
				array(
					'key'     => 'first_name',
					'value'   => $term,
					'compare' => 'LIKE',
				),
				array(
					'key'     => 'last_name',
					'value'   => $term,
					'compare' => 'LIKE',
				),
			);

			$meta_args               = $base_args;
			$meta_args['meta_query'] = $test_clause
				? array( 'relation' => 'AND', $name_clause, $test_clause )
				: $name_clause;

			$ids = array_values( array_unique( array_merge( get_users( $search_args ), get_users( $meta_args ) ) ) );
		} else {
			$recent_args            = $base_args;
			$recent_args['orderby'] = 'ID';
			$recent_args['order']   = 'DESC';

			if ( $test_clause ) {
				$recent_args['meta_query'] = array( $test_clause );
			}

			$ids = get_users( $recent_args );
		}

		$ids = array_slice( $ids, 0, 20 );

		$items = array();

		foreach ( $ids as $user_id ) {
			$user = get_userdata( $user_id );
			if ( ! $user ) {
				continue;
			}

			$first = get_user_meta( $user_id, 'first_name', true );
			$last  = get_user_meta( $user_id, 'last_name', true );
			$name  = trim( $first . ' ' . $last );
			if ( '' === $name ) {
				$name = $user->display_name;
			}

			$items[] = array(
				'id'    => (int) $user_id,
				'label' => sprintf( '#%d — %s <%s>', $user_id, $name, $user->user_email ),
			);
		}

		wp_send_json_success( array( 'items' => $items ) );
	}

	/**
	 * Construye la cláusula de `meta_query` que filtra usuarios según si
	 * realizaron o no el test, a partir del metadato `question_test_ids`
	 * (mismo criterio usado en el resto del ecosistema WMS Latam: se
	 * considera "con test" cuando el valor existe y no está vacío).
	 *
	 * @param string $test_filter '', 'con_test' o 'sin_test'.
	 * @return array|null
	 */
	private function build_test_meta_query_clause( $test_filter ) {
		if ( 'con_test' === $test_filter ) {
			return array(
				'key'     => 'question_test_ids',
				'value'   => '',
				'compare' => '!=',
			);
		}

		if ( 'sin_test' === $test_filter ) {
			return array(
				'relation' => 'OR',
				array(
					'key'     => 'question_test_ids',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'question_test_ids',
					'value'   => '',
					'compare' => '=',
				),
			);
		}

		return null;
	}

	/**
	 * AJAX: construye y devuelve el JSON de previsualización para un
	 * usuario, reutilizando `UDA_User_Data::build()` — la misma función
	 * que usa el endpoint REST real — para que la previsualización
	 * nunca pueda divergir de la respuesta real de la API.
	 *
	 * @return void
	 */
	public function ajax_preview_user() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'No autorizado.', 'user-data-api' ) ), 403 );
		}

		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$user    = $user_id ? get_userdata( $user_id ) : false;

		if ( ! $user ) {
			wp_send_json_error( array( 'message' => __( 'Usuario no encontrado.', 'user-data-api' ) ), 404 );
		}

		$response = array(
			'success' => true,
			'user'    => UDA_User_Data::build( $user ),
		);

		wp_send_json_success( array( 'response' => $response ) );
	}

	/**
	 * AJAX: crea una empresa real (y sus áreas, si se enviaron) desde la
	 * herramienta de prueba de la página "API Crear empresa", reutilizando
	 * `UDA_Company::crear_empresa_con_areas()` — la misma función que usa
	 * el endpoint REST real — para que la prueba nunca pueda divergir de
	 * la respuesta real de la API.
	 *
	 * @return void
	 */
	public function ajax_crear_empresa_test() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'No autorizado.', 'user-data-api' ) ), 403 );
		}

		$user_email       = isset( $_POST['user_email'] ) ? sanitize_text_field( wp_unslash( $_POST['user_email'] ) ) : '';
		$nombre_empresa   = isset( $_POST['nombre_empresa'] ) ? sanitize_text_field( wp_unslash( $_POST['nombre_empresa'] ) ) : '';
		$nombre_encargado = isset( $_POST['nombre_encargado'] ) ? sanitize_text_field( wp_unslash( $_POST['nombre_encargado'] ) ) : '';
		$contacto         = isset( $_POST['contacto'] ) ? sanitize_text_field( wp_unslash( $_POST['contacto'] ) ) : '';
		$ocupacion        = isset( $_POST['ocupacion'] ) ? sanitize_text_field( wp_unslash( $_POST['ocupacion'] ) ) : '';

		// "areas" llega como JSON (texto) desde el textarea de la
		// herramienta de prueba, igual que llegaría en el body de la
		// petición REST real; se decodifica aquí para pasarlo tal cual a
		// la misma función de validación que usa el endpoint.
		$areas_json = isset( $_POST['areas'] ) ? wp_unslash( $_POST['areas'] ) : '';
		$areas      = ( '' !== trim( $areas_json ) ) ? json_decode( $areas_json, true ) : array();

		if ( '' !== trim( $areas_json ) && null === $areas && 'null' !== trim( strtolower( $areas_json ) ) ) {
			wp_send_json_error( array( 'message' => __( 'El JSON de "areas" no es válido.', 'user-data-api' ) ) );
		}

		$resultado = UDA_Company::crear_empresa_con_areas( $user_email, $nombre_empresa, $nombre_encargado, $contacto, $ocupacion, $areas );

		if ( is_wp_error( $resultado ) ) {
			wp_send_json_error( array( 'message' => $resultado->get_error_message() ) );
		}

		$response = array(
			'success'            => true,
			'message'            => __( 'La empresa se ha registrado correctamente.', 'user-data-api' ),
			'empresa'            => array(
				'user_id'        => $resultado['usuario_id'],
				'nombre_empresa' => $nombre_empresa,
				'email'          => $resultado['user_email'],
				'password'       => $resultado['password'],
				'rol'            => 'company',
			),
			'areas'              => $resultado['areas'],
			'defaults_aplicados' => $resultado['defaults_aplicados'],
		);

		wp_send_json_success( array( 'response' => $response ) );
	}
}
