<?php
/**
 * Autenticación del endpoint REST mediante Bearer Token.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Auth {

	/**
	 * Módulo de ajustes, usado para leer el token configurado.
	 *
	 * @var UDA_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param UDA_Settings $settings Instancia del módulo de ajustes.
	 */
	public function __construct( UDA_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Callback de `permission_callback` para la ruta REST del plugin.
	 *
	 * Se ejecuta ANTES que el callback principal del endpoint: si el
	 * token no es válido, la petición nunca llega a buscar ni exponer
	 * datos de ningún usuario.
	 *
	 * Devolver `true` autoriza la petición; devolver un `WP_Error` hace
	 * que WordPress responda automáticamente con ese error (incluyendo
	 * el código de estado HTTP configurado en el `WP_Error`).
	 *
	 * @param WP_REST_Request $request Petición REST entrante.
	 * @return true|WP_Error
	 */
	public function check_bearer_token( WP_REST_Request $request ) {
		$header = $request->get_header( 'authorization' );

		if ( empty( $header ) ) {
			return $this->unauthorized( __( 'Falta la cabecera Authorization.', 'user-data-api' ) );
		}

		if ( ! preg_match( '/^Bearer\s+(.+)$/i', trim( $header ), $matches ) ) {
			return $this->unauthorized( __( 'Formato de cabecera Authorization inválido. Se espera "Bearer TOKEN".', 'user-data-api' ) );
		}

		$received_token   = trim( $matches[1] );
		$configured_token = $this->settings->get_token();

		if ( '' === $configured_token ) {
			// Si no hay token configurado, el endpoint no puede validarse
			// de forma segura: se rechaza la petición en vez de dejarlo
			// abierto por accidente.
			return $this->unauthorized( __( 'El token de autenticación no ha sido configurado en el servidor.', 'user-data-api' ) );
		}

		// hash_equals() compara en tiempo constante para evitar timing attacks.
		if ( '' === $received_token || ! hash_equals( $configured_token, $received_token ) ) {
			return $this->unauthorized( __( 'Token inválido.', 'user-data-api' ) );
		}

		return true;
	}

	/**
	 * Construye un WP_Error estandarizado de 401 para respuestas de auth.
	 *
	 * @param string $message Mensaje descriptivo del error.
	 * @return WP_Error
	 */
	private function unauthorized( $message ) {
		return new WP_Error(
			'uda_unauthorized',
			$message,
			array(
				'status'  => 401,
				'success' => false,
			)
		);
	}
}
