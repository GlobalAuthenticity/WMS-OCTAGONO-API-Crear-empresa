<?php
/**
 * Registro y lógica del endpoint REST público del plugin.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Api {

	/**
	 * Namespace de la REST API.
	 *
	 * @var string
	 */
	const NAMESPACE = 'user-data-api/v1';

	/**
	 * Ruta del endpoint dentro del namespace.
	 *
	 * @var string
	 */
	const ROUTE = '/user';

	/**
	 * Ruta alterna, idéntica en comportamiento a self::ROUTE, que evita
	 * terminar en "/user". Varios plugins de seguridad (Wordfence entre
	 * ellos) traen reglas de firewall que bloquean por patrón cualquier
	 * ruta REST que termine en "/user" o "/users" como protección contra
	 * enumeración de usuarios (pensada originalmente para blindar
	 * `/wp-json/wp/v2/users` del core), y esas reglas no distinguen esa
	 * ruta de esta — coinciden por el sufijo, no por el namespace. Esta
	 * ruta alterna deja disponible una URL equivalente que no cae en ese
	 * patrón, sin depender de tocar la configuración de ningún plugin de
	 * seguridad. La ruta original se mantiene activa por compatibilidad
	 * con integraciones que ya la usen.
	 *
	 * @var string
	 */
	const ROUTE_ALT = '/lookup';

	/**
	 * Módulo de autenticación.
	 *
	 * @var UDA_Auth
	 */
	private $auth;

	/**
	 * Constructor.
	 *
	 * @param UDA_Auth $auth Instancia del módulo de autenticación.
	 */
	public function __construct( UDA_Auth $auth ) {
		$this->auth = $auth;
	}

	/**
	 * Registra los hooks necesarios de WordPress.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Registra las rutas REST `POST /user-data-api/v1/user` (original) y
	 * `POST /user-data-api/v1/lookup` (alterna, ver self::ROUTE_ALT) —
	 * ambas con exactamente el mismo callback, permisos y argumentos, así
	 * que nunca pueden divergir en comportamiento entre sí.
	 *
	 * @return void
	 */
	public function register_routes() {
		$route_args = array(
			'methods'             => WP_REST_Server::CREATABLE, // POST.
			'callback'            => array( $this, 'handle_request' ),
			'permission_callback' => array( $this->auth, 'check_bearer_token' ),
			'args'                => array(
				'user_id' => array(
					'required'          => false,
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
				),
				'email'   => array(
					'required'          => false,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_email',
				),
			),
		);

		register_rest_route( self::NAMESPACE, self::ROUTE, $route_args );
		register_rest_route( self::NAMESPACE, self::ROUTE_ALT, $route_args );
	}

	/**
	 * Callback principal: valida los parámetros, busca al usuario (por
	 * `user_id` o `email`) y devuelve su información completa.
	 *
	 * El endpoint solo puede devolver información de UN usuario por
	 * petición, identificado por ID exacto o correo exacto — nunca
	 * acepta listados, comodines ni parámetros que permitan enumerar
	 * usuarios.
	 *
	 * @param WP_REST_Request $request Petición REST entrante.
	 * @return WP_REST_Response
	 */
	public function handle_request( WP_REST_Request $request ) {
		$user_id = absint( $request->get_param( 'user_id' ) );

		$email = $request->get_param( 'email' );
		$email = is_string( $email ) ? sanitize_email( trim( $email ) ) : '';

		// 1. Validar que se haya enviado al menos uno de los dos.
		if ( ! $user_id && '' === $email ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Debes enviar "user_id" o "email".', 'user-data-api' ),
				),
				400
			);
		}

		// 2. Si se envió correo (y no user_id), validar su formato.
		if ( ! $user_id && '' !== $email && ! is_email( $email ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'El formato del correo electrónico no es válido.', 'user-data-api' ),
				),
				400
			);
		}

		// 3-4. Buscar el usuario; si no existe, error claro.
		$user = UDA_User_Data::resolve_user( $user_id, $email );

		if ( ! $user ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Usuario no encontrado.', 'user-data-api' ),
				),
				404
			);
		}

		// 5. Usuario encontrado: construir y devolver su información completa.
		return new WP_REST_Response(
			array(
				'success' => true,
				'user'    => UDA_User_Data::build( $user ),
			),
			200
		);
	}
}
