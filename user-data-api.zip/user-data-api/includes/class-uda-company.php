<?php
/**
 * Modelo: creación de empresas (usuarios con rol `group_admin`).
 *
 * Replica la lógica de negocio de `AEO_Companies::crear_empresa()` del
 * plugin "Administrar Empresa Octágono" (mismo botón "Crear Empresa" del
 * panel de administración de ese plugin), de forma autocontenida en este
 * plugin para que el endpoint REST no dependa de que aquel esté activo.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Company {

	/**
	 * Rol de WordPress asignado a las empresas, igual que en el resto del
	 * ecosistema WMS Latam ("Administrar Empresa Octágono", "Áreas
	 * Asignadas", "User Data API" al resolver `company`/`area`).
	 *
	 * @var string
	 */
	const ROLE = 'group_admin';

	/**
	 * Crea una empresa y, opcionalmente, sus áreas, como una sola
	 * operación de negocio: primero valida y normaliza TODO el arreglo
	 * `areas` (sin tocar la base de datos), y solo si es válido procede a
	 * crear la empresa y luego cada área. Así, si alguna área viene mal
	 * formada, la petición se rechaza completa y no se crea ningún
	 * usuario ni área — evita dejar una empresa creada sin las áreas que
	 * se pidieron junto con ella.
	 *
	 * Si `areas` se omite, llega vacío o llega `null` (es decir, no se
	 * pidió ninguna área), se crea automáticamente UN área por defecto:
	 * "Área demo", 2 cupos, con `fecha_expiracion` = hoy + 6 meses (igual
	 * que `UDA_Area::fecha_por_defecto()`). Esto se refleja también en
	 * `defaults_aplicados` (se agrega `'areas'`).
	 *
	 * @param string|null $user_email       Ver `crear_empresa()`.
	 * @param string      $nombre_empresa   Ver `crear_empresa()`.
	 * @param string|null $nombre_encargado Ver `crear_empresa()`.
	 * @param string|null $contacto         Ver `crear_empresa()`.
	 * @param string|null $ocupacion        Ver `crear_empresa()`.
	 * @param mixed       $areas_input      Arreglo de áreas a crear (ver `UDA_Area::validar_y_normalizar_areas()`), o null/vacío/ausente para usar el área por defecto.
	 * @return array|WP_Error Igual que `crear_empresa()`, más la clave `areas`: lista de resultados por área (cada una con `success` true/false).
	 */
	public static function crear_empresa_con_areas( $user_email, $nombre_empresa, $nombre_encargado, $contacto, $ocupacion, $areas_input ) {
		$areas_normalizadas = UDA_Area::validar_y_normalizar_areas( $areas_input );

		if ( is_wp_error( $areas_normalizadas ) ) {
			return $areas_normalizadas;
		}

		$area_por_defecto_aplicada = false;

		if ( empty( $areas_normalizadas ) ) {
			// No se pidió ninguna área (se omitió "areas", llegó vacío o
			// null): se crea una de cortesía para que la empresa no quede
			// sin ningún área asignada.
			$areas_normalizadas = array(
				array(
					'nombre'           => __( 'Área demo', 'user-data-api' ),
					'cupos'            => 2,
					'fecha_expiracion' => UDA_Area::fecha_por_defecto(),
				),
			);

			$area_por_defecto_aplicada = true;
		}

		$resultado = self::crear_empresa( $user_email, $nombre_empresa, $nombre_encargado, $contacto, $ocupacion );

		if ( is_wp_error( $resultado ) ) {
			return $resultado;
		}

		if ( $area_por_defecto_aplicada ) {
			$resultado['defaults_aplicados'][] = 'areas';
		}

		$areas_creadas = array();

		foreach ( $areas_normalizadas as $area ) {
			$area_resultado = UDA_Area::crear_area( $resultado['usuario_id'], $area['nombre'], $area['cupos'], $area['fecha_expiracion'] );

			if ( is_wp_error( $area_resultado ) ) {
				// La empresa ya quedó creada (es la fuente de verdad): un
				// fallo puntual al insertar un área específica no revierte
				// la empresa ni las demás áreas, solo se reporta en la
				// respuesta para que quien consume la API pueda reintentar
				// esa área puntual.
				$areas_creadas[] = array(
					'nombre'  => $area['nombre'],
					'success' => false,
					'message' => $area_resultado->get_error_message(),
				);
				continue;
			}

			$area_resultado['success'] = true;
			$areas_creadas[]           = $area_resultado;
		}

		$resultado['areas'] = $areas_creadas;

		return $resultado;
	}

	/**
	 * Crea una nueva empresa (usuario con rol `group_admin`).
	 *
	 * Si no se envía `user_email` (vacío, null o ausente), se autogenera a
	 * partir de `nombre_empresa` con el formato `admin.(slug)@wmslatam.com`,
	 * donde `slug` es el nombre de la empresa en minúsculas, sin acentos,
	 * sin caracteres especiales/espacios y sin la palabra "demo" (ver
	 * `generar_correo_desde_nombre_empresa()`).
	 *
	 * @param string|null $user_email       Correo electrónico. Opcional: se autogenera si falta.
	 * @param string      $nombre_empresa   Nombre de la empresa (display_name / nickname / first_name del usuario). Obligatorio.
	 * @param string|null $nombre_encargado Nombre del encargado (meta 'nombre_encargado'). Opcional: si falta, se usa "José Martínez".
	 * @param string|null $contacto         Teléfono de contacto (meta 'phone_number'). Opcional: si falta, se usa un número aleatorio.
	 * @param string|null $ocupacion        Ocupación (meta 'occupation'). Opcional: si falta, se usa "Administrador WMS".
	 * @return array|WP_Error {
	 *     @type int      $usuario_id         ID del usuario creado.
	 *     @type string   $user_email         Correo final usado (el enviado, o el autogenerado).
	 *     @type string   $password           Contraseña generada, en texto plano (ver nota de seguridad más abajo).
	 *     @type array    $roles              Roles asignados.
	 *     @type string   $autologin_url      URL de autologin válida por 15 minutos.
	 *     @type string[] $defaults_aplicados Nombres de los campos opcionales que llegaron vacíos/null/ausentes y se completaron con un valor por defecto (valores posibles: 'email', 'nombre_encargado', 'contacto', 'ocupacion').
	 * }
	 */
	public static function crear_empresa( $user_email, $nombre_empresa, $nombre_encargado = '', $contacto = '', $ocupacion = '' ) {
		$defaults_aplicados = array();

		// ----------------------------------
		// Validaciones.
		// ----------------------------------
		// El nombre de la empresa se valida primero porque el correo
		// autogenerado (cuando no se envía uno) depende de él.
		$nombre_empresa = sanitize_text_field( trim( (string) $nombre_empresa ) );

		if ( empty( $nombre_empresa ) ) {
			return new WP_Error( 'nombre_requerido', __( 'El nombre de la empresa es obligatorio.', 'user-data-api' ) );
		}

		if ( self::existe_empresa_con_nombre( $nombre_empresa ) ) {
			return new WP_Error( 'empresa_existente', __( 'Ya existe una empresa registrada con ese nombre.', 'user-data-api' ) );
		}

		$user_email = is_string( $user_email ) ? sanitize_email( trim( $user_email ) ) : '';

		if ( empty( $user_email ) ) {
			// No se envió correo: se autogenera a partir del nombre de la empresa.
			$user_email           = self::generar_correo_desde_nombre_empresa( $nombre_empresa );
			$defaults_aplicados[] = 'email';
		} elseif ( ! is_email( $user_email ) ) {
			return new WP_Error( 'correo_invalido', __( 'El correo electrónico no tiene un formato válido.', 'user-data-api' ) );
		}

		if ( email_exists( $user_email ) ) {
			return new WP_Error( 'usuario_existente', __( 'Ya existe un usuario registrado con ese correo electrónico.', 'user-data-api' ) );
		}

		// Nombre del encargado: si llega vacío, null o no se envía, se usa
		// un valor por defecto en vez de dejar el campo en blanco.
		$nombre_encargado = is_string( $nombre_encargado ) ? sanitize_text_field( trim( $nombre_encargado ) ) : '';

		if ( empty( $nombre_encargado ) ) {
			$nombre_encargado     = __( 'José Martínez', 'user-data-api' );
			$defaults_aplicados[] = 'nombre_encargado';
		}

		// Contacto: si llega vacío, null o no se envía, se usa un número
		// telefónico aleatorio en vez de dejar el campo en blanco.
		$contacto = is_string( $contacto ) ? sanitize_text_field( trim( $contacto ) ) : '';

		if ( empty( $contacto ) ) {
			$contacto             = self::generar_telefono_aleatorio();
			$defaults_aplicados[] = 'contacto';
		}

		// Ocupación: si llega vacía, null o no se envía, se usa un valor
		// por defecto en vez de dejar el campo en blanco.
		$ocupacion = is_string( $ocupacion ) ? sanitize_text_field( trim( $ocupacion ) ) : '';

		if ( empty( $ocupacion ) ) {
			$ocupacion            = __( 'Administrador WMS', 'user-data-api' );
			$defaults_aplicados[] = 'ocupacion';
		}

		// ----------------------------------
		// 1. Crear usuario. La contraseña se genera sin caracteres
		// especiales (solo letras y números) para evitar incompatibilidades
		// al enviarla a integraciones externas.
		// ----------------------------------
		$password = wp_generate_password( 14, false, false );

		$usuario_id = wp_insert_user(
			array(
				'user_login' => $user_email,
				'user_pass'  => $password,
				'user_email' => $user_email,
				'nickname'   => $nombre_empresa,
				'first_name' => $nombre_empresa,
			)
		);

		if ( is_wp_error( $usuario_id ) ) {
			return $usuario_id;
		}

		// ----------------------------------
		// 2. Metadatos.
		// ----------------------------------
		update_user_meta( $usuario_id, 'nombre_encargado', $nombre_encargado );
		update_user_meta( $usuario_id, 'phone_number', $contacto );
		update_user_meta( $usuario_id, 'occupation', $ocupacion );
		update_user_meta( $usuario_id, 'grupo', 'true' );
		update_user_meta( $usuario_id, 'membresia_activa', 'true' );

		// ----------------------------------
		// 3. Rol.
		// ----------------------------------
		$wp_user = new WP_User( $usuario_id );
		$wp_user->set_role( self::ROLE );

		// ----------------------------------
		// 4. Token de autologin (15 minutos), mismo esquema usado en el
		// resto del ecosistema WMS Latam (`mi_autologin_token` / `mi_autologin_expires`).
		// ----------------------------------
		$autologin_token = wp_generate_password( 40, false, false );

		update_user_meta( $usuario_id, 'mi_autologin_token', $autologin_token );
		update_user_meta( $usuario_id, 'mi_autologin_expires', time() + 900 );

		$autologin_url = add_query_arg(
			array(
				'mi_autologin' => 1,
				'uid'          => $usuario_id,
				'token'        => $autologin_token,
			),
			home_url( '/' )
		);

		// ----------------------------------
		// 5. Resultado.
		//
		// NOTA DE SEGURIDAD: aquí SÍ se devuelve la contraseña en texto
		// plano (a diferencia de versiones anteriores de este endpoint).
		// Es una decisión explícita: este endpoint no sincroniza con
		// wmslatam.com ni envía correo de bienvenida (a diferencia del
		// botón "Crear Empresa" de Administrar Empresa Octágono), así que
		// no hay otro canal para entregar la contraseña a quien creó la
		// empresa. Quien consuma esta API es responsable de transmitirla
		// de forma segura (HTTPS ya obligatorio) y no almacenarla en logs.
		// ----------------------------------
		return array(
			'usuario_id'         => $usuario_id,
			'user_email'         => $user_email,
			'password'           => $password,
			'roles'              => $wp_user->roles,
			'autologin_url'      => $autologin_url,
			'defaults_aplicados' => $defaults_aplicados,
		);
	}

	/**
	 * Comprueba si ya existe una empresa (usuario con rol `group_admin`)
	 * registrada con ese mismo nombre, comparando contra el meta
	 * `nickname` (el mismo campo donde se guarda `nombre_empresa` al
	 * crear la empresa). La comparación queda a cargo de la collation por
	 * defecto de la base de datos, que en una instalación estándar de
	 * WordPress es insensible a mayúsculas/minúsculas — "Acme S.A.S." y
	 * "acme s.a.s." se consideran el mismo nombre.
	 *
	 * @param string $nombre_empresa Nombre de la empresa ya sanitizado/no vacío.
	 * @return bool
	 */
	private static function existe_empresa_con_nombre( $nombre_empresa ) {
		$usuarios = get_users(
			array(
				'role'       => self::ROLE,
				'meta_key'   => 'nickname',
				'meta_value' => $nombre_empresa,
				'fields'     => 'ID',
				'number'     => 1,
			)
		);

		return ! empty( $usuarios );
	}

	/**
	 * Autogenera un correo `admin.(slug)@wmslatam.com` a partir del nombre
	 * de la empresa, y garantiza que no colisione con un correo ya
	 * existente (probando sufijos numéricos y, en último caso, uno
	 * aleatorio).
	 *
	 * @param string $nombre_empresa Nombre de la empresa ya sanitizado/no vacío.
	 * @return string
	 */
	private static function generar_correo_desde_nombre_empresa( $nombre_empresa ) {
		$slug = self::slug_desde_nombre_empresa( $nombre_empresa );

		if ( '' === $slug ) {
			// El nombre quedó vacío tras limpiar acentos/caracteres
			// especiales/"demo" (ej. nombre_empresa = "Demo" o "¡¡¡!!!"):
			// se usa un slug de respaldo para que el correo siga siendo válido.
			$slug = 'empresa' . strtolower( wp_generate_password( 6, false, false ) );
		}

		$email_base = 'admin.' . $slug . '@wmslatam.com';

		if ( ! email_exists( $email_base ) ) {
			return $email_base;
		}

		// El slug ya está en uso (otra empresa con el mismo nombre, una vez
		// limpiado): se agregan sufijos numéricos hasta encontrar uno libre.
		for ( $intento = 2; $intento <= 20; $intento++ ) {
			$email_intento = 'admin.' . $slug . $intento . '@wmslatam.com';

			if ( ! email_exists( $email_intento ) ) {
				return $email_intento;
			}
		}

		// Último recurso (muy improbable): sufijo aleatorio.
		return 'admin.' . $slug . '-' . strtolower( wp_generate_password( 4, false, false ) ) . '@wmslatam.com';
	}

	/**
	 * Genera un número de teléfono aleatorio de 10 dígitos con formato de
	 * celular colombiano (empieza en "3"), usado como valor de respaldo
	 * para `contacto` cuando no se envía uno. No se valida contra
	 * duplicados: es un dato de relleno, no un identificador único.
	 *
	 * @return string
	 */
	private static function generar_telefono_aleatorio() {
		$numero = '3';

		for ( $i = 0; $i < 9; $i++ ) {
			$numero .= (string) wp_rand( 0, 9 );
		}

		return $numero;
	}

	/**
	 * Convierte el nombre de una empresa en un slug apto para la parte
	 * local de un correo: minúsculas, sin acentos, sin la palabra "demo"
	 * (como palabra completa, en cualquier posición) y sin ningún
	 * carácter que no sea letra o número (espacios, puntos, guiones,
	 * símbolos, etc. se eliminan, no se reemplazan).
	 *
	 * El orden importa: la palabra "demo" se quita ANTES de eliminar los
	 * demás caracteres especiales, para poder detectarla como palabra
	 * completa usando los espacios/puntuación originales como límites
	 * (si se limpiara todo primero, "Empresa Demo" y "Empresa X Demo123"
	 * quedarían pegadas y ya no se podría distinguir "demo" como palabra).
	 *
	 * @param string $nombre_empresa Nombre de la empresa.
	 * @return string Slug en minúsculas, solo [a-z0-9], truncado a 40 caracteres.
	 */
	private static function slug_desde_nombre_empresa( $nombre_empresa ) {
		$texto = remove_accents( (string) $nombre_empresa );
		$texto = strtolower( $texto );
		$texto = preg_replace( '/\bdemo\b/iu', '', $texto );
		$texto = preg_replace( '/[^a-z0-9]/', '', $texto );

		return substr( (string) $texto, 0, 40 );
	}
}
