<?php
/**
 * Construcción de la información completa de un usuario.
 *
 * Única fuente de verdad para armar la respuesta: tanto el endpoint REST
 * (UDA_Api) como la previsualización del panel de administración
 * (UDA_Admin) llaman exactamente a `UDA_User_Data::build()`, así que
 * nunca pueden divergir entre lo que se muestra en el admin y lo que
 * realmente devuelve la API.
 *
 * Las relaciones de empresa/área y la lógica de "perfil completo" y
 * "resultados del test" replican exactamente las ya usadas en el resto
 * del ecosistema Octágono (plugins "Administrar Empresa Octágono" y
 * "Áreas Asignadas"), en vez de inventar una estructura nueva:
 *
 * - Perfil completo: mismos 7 campos de wp_usermeta que
 *   AU_Repository_Usuarios::esta_perfil_completo().
 * - Empresa/Área: wp_user_members (user_id, area_id, status,
 *   fecha_final_membresia) + wp_areas (id, nombre, cupo, estado,
 *   fecha_expiracion, grupo_id) — mismas tablas que usan
 *   "administrar-empresa-octagono" (AEO_Areas/AEO_Companies) y
 *   "areas-asignadas". `wp_user_members.area_id` apunta al área; el
 *   `grupo_id` del área es el ID del usuario-empresa. La empresa es en
 *   sí un wp_user con rol `group_admin` (AEO_COMPANY_ROLE). Este
 *   proyecto no usa `wp_correos_configurados` ni `wp_paquetes` (esas
 *   son de otro proyecto del ecosistema); tampoco existe aquí una
 *   tabla `wp_licencias`, por lo que company/area no incluyen licencia.
 * - Test ("Sentido Vital" / Escala Dimensional del Sentido de vida):
 *   wp_usermeta `question_test_ids` guarda las respuestas crudas en JSON
 *   (array de objetos {question, answer, value}, 17 preguntas, valor
 *   0-3 cada una, ya normalizado por dirección directa/inversa desde el
 *   front-end — ver astra-child/assets/js/test.js). El promedio y la
 *   clasificación NO se reinventan aquí: se recalculan con exactamente
 *   la misma fórmula y los mismos umbrales que usa el tema en 3 sitios
 *   distintos que deben coincidir entre sí:
 *     - Página pública /resultado-test/ (resultado individual):
 *       astra-child/assets/js/result.js, `senseClassification`.
 *     - Informe por área: astra-child/app/test/ajax/get-test-result-by-area-id.php,
 *       `$sense_classification` + `get_user_test_average()`.
 *     - Informe por empresa: astra-child/app/test/ajax/get-test-result-by-group.php,
 *       mismos umbrales.
 *   Los 3 calculan `promedio = suma_de_valores / 17` y lo ubican en uno
 *   de 4 niveles (búsqueda / medio / alto sentido vital / plenitud de
 *   sentido) con los mismos cortes (2.65 / 2.35 / 2.00). Ver `SENSE_LEVELS`
 *   más abajo para el detalle exacto de cada nivel.
 *
 *   Nota: la página /resultado-test/ además arma un texto narrativo
 *   personalizado por pregunta (mostrando/ocultando párrafos fijos según
 *   la respuesta exacta a ciertas preguntas — ver `displayParagraph()` en
 *   result.js), pero ese texto vive como contenido de Elementor en esa
 *   página (fuera del código), no en una función reutilizable — por eso
 *   no se reproduce aquí; `test.results.classification.description` da
 *   en cambio el resumen corto de cada nivel (el mismo que ve el usuario
 *   en las 4 tarjetas de esa página).
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_User_Data {

	/**
	 * Campos de wp_usermeta que determinan si el perfil está completo.
	 * Idéntico al criterio usado en el plugin "Administrador de
	 * Usuarios" (AU_Repository_Usuarios::esta_perfil_completo()) para
	 * que ambos paneles siempre coincidan.
	 *
	 * @var string[]
	 */
	const PROFILE_REQUIRED_META_KEYS = array(
		'first_name',
		'last_name',
		'user_age',
		'user_gender',
		'country',
		'phone_number',
		'user_position',
	);

	/**
	 * Rol de WordPress asignado a los usuarios-empresa. Mismo valor que
	 * la constante `AEO_COMPANY_ROLE` del plugin
	 * "administrar-empresa-octagono"; se repite aquí en vez de depender
	 * de esa constante para no acoplar este plugin a que el otro esté
	 * activo.
	 *
	 * @var string
	 */
	const COMPANY_ROLE = 'group_admin';

	/**
	 * Número de preguntas del test "Sentido Vital". El promedio se
	 * calcula siempre como `suma_de_valores / 17`, exactamente igual que
	 * `proccess_test_answers()` (get-test-result.php),
	 * `proccess_test_answers_user()` (get-test-result-by-id.php) y
	 * `get_user_test_average()` (get-test-result-by-area-id.php) en el
	 * tema astra-child.
	 *
	 * @var int
	 */
	const SENSE_QUESTION_COUNT = 17;

	/**
	 * Escala de interpretación del test "Sentido Vital", única fuente de
	 * verdad para clasificar el promedio. Umbrales y etiquetas idénticos
	 * a `senseClassification` en astra-child/assets/js/result.js (página
	 * pública /resultado-test/) y a `$sense_classification` en
	 * get-test-result-by-area-id.php / get-test-result-by-group.php
	 * (informes por área/empresa) — no se inventan umbrales nuevos.
	 *
	 * Ordenado de mayor a menor para que `classify_sense_level()` lo
	 * recorra como el mismo if/elseif que usan esos 3 archivos.
	 *
	 * Las descripciones son el resumen corto que ve el usuario en las 4
	 * tarjetas de esa página; el texto largo personalizado por pregunta
	 * vive como contenido de Elementor en la página, no en código (ver
	 * nota en el docblock de la clase).
	 *
	 * @var array<string,array{label:string,min:float,max:float,description:string}>
	 */
	const SENSE_LEVELS = array(
		'plenitud-sentido' => array(
			'label'       => 'Plenitud de sentido',
			'min'         => 2.65,
			'max'         => 3.0,
			'description' => 'Personas que experimentan su vida llena de significado.',
		),
		'alto-sentido'     => array(
			'label'       => 'Alto sentido vital',
			'min'         => 2.35,
			'max'         => 2.64,
			'description' => 'Personas que generalmente tienen claras sus metas y las razones por las que actúan en su vida, aunque en ocasiones se alejan de su rumbo claro.',
		),
		'medio-sentido'    => array(
			'label'       => 'Medio sentido vital',
			'min'         => 2.0,
			'max'         => 2.34,
			'description' => 'Personas que entienden algunas de las razones por las que actúan en su vida, pero en ciertas áreas pueden experimentar cierta desmotivación.',
		),
		'busqueda-sentido' => array(
			'label'       => 'Búsqueda de sentido vital',
			'min'         => 0.0,
			'max'         => 1.99,
			'description' => 'Personas que en algunas ocasiones experimentan su vida sin sentido ni propósito.',
		),
	);

	/**
	 * Resuelve un WP_User a partir de un `user_id` o un `email`.
	 *
	 * Si se envían ambos, `user_id` tiene prioridad. Solo permite
	 * consultar UN usuario a la vez (por ID exacto o correo exacto);
	 * nunca hace búsquedas parciales ni devuelve listados, para no
	 * permitir enumeración de usuarios desde la API.
	 *
	 * @param int    $user_id ID de usuario (0 si no se envió).
	 * @param string $email   Correo electrónico (ya sanitizado; '' si no se envió).
	 * @return WP_User|null
	 */
	public static function resolve_user( $user_id, $email ) {
		$user_id = absint( $user_id );

		if ( $user_id > 0 ) {
			$user = get_user_by( 'id', $user_id );
			return ( $user instanceof WP_User ) ? $user : null;
		}

		$email = is_string( $email ) ? trim( $email ) : '';

		if ( '' !== $email && is_email( $email ) ) {
			$user = get_user_by( 'email', $email );
			return ( $user instanceof WP_User ) ? $user : null;
		}

		return null;
	}

	/**
	 * Construye el array completo de información del usuario.
	 *
	 * Deliberadamente NO incluye `user_pass`, hashes, activation keys ni
	 * ningún otro metadato sensible/interno de wp_usermeta: solo los
	 * campos explícitamente pedidos (perfil básico, estado de perfil,
	 * empresa, área, cursos y test).
	 *
	 * @param WP_User $user Usuario ya resuelto.
	 * @return array
	 */
	public static function build( WP_User $user ) {
		$user_id = (int) $user->ID;

		$first_name = get_user_meta( $user_id, 'first_name', true );
		$last_name  = get_user_meta( $user_id, 'last_name', true );

		$full_name = trim( $first_name . ' ' . $last_name );
		if ( '' === $full_name ) {
			$full_name = $user->display_name ? $user->display_name : $user->user_login;
		}

		$vinculo = self::get_company_and_area( $user );

		return array(
			'id'            => $user_id,
			'email'         => $user->user_email,
			'username'      => $user->user_login,
			'first_name'    => (string) $first_name,
			'last_name'     => (string) $last_name,
			'full_name'     => $full_name,
			'roles'         => array_values( (array) $user->roles ),
			'registered_at' => $user->user_registered,
			'profile'       => array(
				'completed' => self::is_profile_completed( $user_id ),
			),
			'company'       => $vinculo['company'],
			'area'          => $vinculo['area'],
			'courses'       => self::get_learndash_courses( $user_id ),
			'test'          => self::get_test_data( $user_id ),
		);
	}

	/**
	 * Determina si el perfil del usuario está completo, verificando que
	 * existan (y no estén vacíos) los 7 campos requeridos en
	 * wp_usermeta. Mismo criterio exacto que el resto del ecosistema
	 * WMS Latam.
	 *
	 * @param int $user_id ID del usuario.
	 * @return bool
	 */
	private static function is_profile_completed( $user_id ) {
		foreach ( self::PROFILE_REQUIRED_META_KEYS as $meta_key ) {
			$value = get_user_meta( $user_id, $meta_key, true );

			if ( '' === trim( (string) $value ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resuelve la empresa y el área del usuario a partir de
	 * `wp_user_members` (membresía usuario↔área) y `wp_areas`
	 * (id, nombre, cupo, estado, fecha_expiracion, grupo_id). Un
	 * usuario puede tener varias filas en `wp_user_members` (por
	 * ejemplo, si fue removido y luego re-inscrito); se toma la más
	 * reciente (mayor ID), igual que el criterio ya usado en
	 * `ultima_fecha_membresia()` (funciones-membresias.php).
	 *
	 * La empresa se resuelve como el usuario `grupo_id` del área
	 * (`wp_areas.grupo_id`), que debe tener el rol `group_admin`
	 * (AEO_COMPANY_ROLE), igual que `AEO_Companies::obtener_empresa_por_id()`.
	 * Si el usuario no tiene ninguna fila en `wp_user_members`, tanto
	 * `company` como `area` quedan en `null`.
	 *
	 * @param WP_User $user Usuario a resolver.
	 * @return array{company:?array,area:?array}
	 */
	private static function get_company_and_area( WP_User $user ) {
		global $wpdb;

		$result = array(
			'company' => null,
			'area'    => null,
		);

		$members_table = $wpdb->prefix . 'user_members';
		$areas_table   = $wpdb->prefix . 'areas';

		$membership = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT area_id, status, fecha_final_membresia FROM {$members_table} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
				$user->ID
			)
		);

		if ( ! $membership || empty( $membership->area_id ) ) {
			return $result;
		}

		$area = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, nombre, cupo, estado, fecha_expiracion, grupo_id FROM {$areas_table} WHERE id = %d LIMIT 1",
				$membership->area_id
			)
		);

		if ( ! $area ) {
			return $result;
		}

		$result['area'] = array(
			'id'         => (int) $area->id,
			'name'       => $area->nombre,
			'quota'      => (int) $area->cupo,
			'status'     => $area->estado,
			'expires_at' => $area->fecha_expiracion,
			'membership' => array(
				'status'     => $membership->status,
				'expires_at' => $membership->fecha_final_membresia,
			),
		);

		$empresa_id = (int) $area->grupo_id;

		if ( $empresa_id > 0 ) {
			$empresa_user = get_userdata( $empresa_id );

			if ( $empresa_user instanceof WP_User && in_array( self::COMPANY_ROLE, (array) $empresa_user->roles, true ) ) {
				$result['company'] = array(
					'id'    => $empresa_id,
					'name'  => $empresa_user->display_name ? $empresa_user->display_name : $empresa_user->user_login,
					'email' => $empresa_user->user_email,
				);
			}
		}

		return $result;
	}

	/**
	 * Devuelve los cursos de LearnDash asignados al usuario, usando las
	 * funciones oficiales de LearnDash (`learndash_get_user_course_access_list()`,
	 * `learndash_course_progress()` y `learndash_course_status()`) en
	 * vez de consultar directamente la base de datos.
	 *
	 * Si LearnDash no está activo, devuelve un array vacío en lugar de
	 * generar un error.
	 *
	 * @param int $user_id ID del usuario.
	 * @return array
	 */
	private static function get_learndash_courses( $user_id ) {
		$courses = array();

		if ( ! function_exists( 'learndash_get_user_course_access_list' ) ) {
			return $courses;
		}

		$course_ids = learndash_get_user_course_access_list( $user_id );

		if ( empty( $course_ids ) || ! is_array( $course_ids ) ) {
			return $courses;
		}

		foreach ( $course_ids as $course_id ) {
			$course_id = (int) $course_id;

			if ( ! $course_id || ! get_post( $course_id ) ) {
				continue;
			}

			$progress = function_exists( 'learndash_course_progress' )
				? learndash_course_progress(
					array(
						'user_id'   => $user_id,
						'course_id' => $course_id,
						'array'     => true,
					)
				)
				: array(
					'percentage' => 0,
					'completed'  => 0,
					'total'      => 0,
				);

			$percentage = isset( $progress['percentage'] ) ? (int) $progress['percentage'] : 0;

			$status = function_exists( 'learndash_course_status' )
				? learndash_course_status( $course_id, $user_id, true )
				: '';

			$courses[] = array(
				'id'                  => $course_id,
				'title'               => get_the_title( $course_id ),
				'status'              => (string) $status,
				'progress_percentage' => $percentage,
				'completed_steps'     => isset( $progress['completed'] ) ? (int) $progress['completed'] : 0,
				'total_steps'         => isset( $progress['total'] ) ? (int) $progress['total'] : 0,
				'completed'           => $percentage >= 100,
			);
		}

		return $courses;
	}

	/**
	 * Devuelve el estado del test del usuario y, si lo realizó, sus
	 * resultados estructurados.
	 *
	 * Las respuestas crudas se guardan en `wp_usermeta` bajo la clave
	 * `question_test_ids` como un JSON de objetos {question, answer,
	 * value} (ver astra-child/assets/js/test.js). El promedio y su
	 * clasificación se recalculan aquí mismo con `build_sense_results()`
	 * (ver ese método y `SENSE_LEVELS` para el detalle de la fórmula y
	 * los umbrales, idénticos a los 3 lugares del tema que ya hacen este
	 * mismo cálculo).
	 *
	 * @param int $user_id ID del usuario.
	 * @return array
	 */
	private static function get_test_data( $user_id ) {
		$raw = get_user_meta( $user_id, 'question_test_ids', true );

		$completed = ( '' !== trim( (string) $raw ) );

		if ( ! $completed ) {
			return array(
				'completed'          => false,
				'question_test_ids'  => null,
				'results'            => null,
			);
		}

		$answers = null;

		if ( is_array( $raw ) ) {
			$answers = $raw;
		} elseif ( is_string( $raw ) ) {
			$decoded = json_decode( stripslashes( $raw ), true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$answers = $decoded;
			}
		}

		$results = is_array( $answers ) ? self::build_sense_results( $answers ) : null;

		return array(
			'completed'         => true,
			'question_test_ids' => is_array( $answers ) ? $answers : $raw,
			'results'           => $results,
		);
	}

	/**
	 * Calcula el promedio del test "Sentido Vital" y lo clasifica,
	 * replicando exactamente `senseClassification` + el bloque
	 * `if (average >= ...)` de astra-child/assets/js/result.js (la
	 * página pública /resultado-test/): promedio = suma de `value` / 17,
	 * clasificado con los cortes de `SENSE_LEVELS`.
	 *
	 * @param array $answers Respuestas decodificadas de `question_test_ids`
	 *                        (array de objetos {question, answer, value}).
	 * @return array
	 */
	private static function build_sense_results( array $answers ) {
		$total = 0.0;

		foreach ( $answers as $answer ) {
			if ( isset( $answer['value'] ) && is_numeric( $answer['value'] ) ) {
				$total += (float) $answer['value'];
			}
		}

		$average = $total / self::SENSE_QUESTION_COUNT;

		$level_key = self::classify_sense_level( $average );
		$level     = self::SENSE_LEVELS[ $level_key ];

		return array(
			'average'        => round( $average, 2 ),
			'scale'          => array(
				'min'             => 0,
				'max'             => 3,
				'question_count'  => self::SENSE_QUESTION_COUNT,
			),
			'classification' => array(
				'key'         => $level_key,
				'label'       => $level['label'],
				'description' => $level['description'],
				'range'       => array(
					'min' => $level['min'],
					'max' => $level['max'],
				),
			),
			// Los 4 niveles posibles, para que un consumidor de la API
			// pueda mostrar la escala completa (igual que las 4 tarjetas
			// de /resultado-test/) sin tener que duplicarla en otro lado.
			'levels'         => self::describe_sense_levels(),
		);
	}

	/**
	 * Determina en qué nivel de `SENSE_LEVELS` cae un promedio, evaluando
	 * de mayor a menor exactamente como el if/elseif de result.js: gana
	 * el primer nivel cuyo mínimo cumple el promedio.
	 *
	 * @param float $average Promedio del test (0 a 3).
	 * @return string Clave de SENSE_LEVELS.
	 */
	private static function classify_sense_level( $average ) {
		foreach ( self::SENSE_LEVELS as $key => $level ) {
			if ( $average >= $level['min'] ) {
				return $key;
			}
		}

		// SENSE_LEVELS cubre desde 0 en adelante, así que esto solo
		// ocurriría con un promedio negativo (datos corruptos); se cae
		// al nivel más bajo en vez de devolver un nivel vacío.
		return 'busqueda-sentido';
	}

	/**
	 * Lista los 4 niveles de `SENSE_LEVELS` en orden ascendente (búsqueda
	 * → medio → alto → plenitud), igual al orden en que se muestran las
	 * 4 tarjetas en /resultado-test/.
	 *
	 * @return array
	 */
	private static function describe_sense_levels() {
		$ordered_keys = array( 'busqueda-sentido', 'medio-sentido', 'alto-sentido', 'plenitud-sentido' );
		$levels       = array();

		foreach ( $ordered_keys as $key ) {
			$level = self::SENSE_LEVELS[ $key ];

			$levels[] = array(
				'key'         => $key,
				'label'       => $level['label'],
				'description' => $level['description'],
				'range'       => array(
					'min' => $level['min'],
					'max' => $level['max'],
				),
			);
		}

		return $levels;
	}
}
