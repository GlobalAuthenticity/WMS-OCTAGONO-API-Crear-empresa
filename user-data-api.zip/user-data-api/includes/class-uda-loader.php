<?php
/**
 * Autoload / arranque de componentes del plugin.
 *
 * Centraliza la carga de clases y la creación/registro de las instancias
 * principales, siguiendo el mismo patrón utilizado en los demás plugins
 * del ecosistema WMS Latam (Administrador de Usuarios, API Usuarios, etc.).
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Loader {

	/**
	 * Carga las clases del plugin y registra sus hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::load_files();

		$settings    = new UDA_Settings();
		$auth        = new UDA_Auth( $settings );
		$api         = new UDA_Api( $auth );
		$company_api = new UDA_Company_Api( $auth );
		$admin       = new UDA_Admin( $settings );

		$settings->register_hooks();
		$api->register_hooks();
		$company_api->register_hooks();

		if ( is_admin() ) {
			$admin->register_hooks();
		}
	}

	/**
	 * Incluye los archivos de clases del plugin.
	 *
	 * @return void
	 */
	private static function load_files() {
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-settings.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-auth.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-user-data.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-api.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-area.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-company.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-company-api.php';
		require_once UDA_PLUGIN_DIR . 'includes/class-uda-admin.php';
	}
}
