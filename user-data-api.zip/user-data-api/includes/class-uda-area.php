<?php
/**
 * Modelo: creación de áreas para una empresa.
 *
 * Replica la lógica de negocio de `AEO_Areas::crear_area()` del plugin
 * "Administrar Empresa Octágono" (mismo botón "Crear Área" del modal de
 * áreas de ese plugin: campos "Nombre del área", "Número de cupos" y
 * "Fecha de expiración"), de forma autocontenida en este plugin para que
 * el endpoint REST no dependa de que aquel esté activo.
 *
 * NOTA: la tabla `wp_areas` de este proyecto solo tiene las columnas que
 * usa AEO_Areas (nombre, cupo, estado, tipo, grupo_id, fecha_expiracion).
 * No existen columnas "codigo" ni "licencia_id" (este proyecto no maneja
 * licencias, ver el propio historial de cambios de este plugin). Si esos
 * campos llegan en la petición, se aceptan sin error pero NO se guardan
 * en ningún lado.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Area {

	/**
	 * Valida y normaliza el arreglo `areas` recibido en la petición, SIN
	 * tocar la base de datos todavía. Se hace como paso separado y previo
	 * a crear la empresa para poder rechazar la petición completa (sin
	 * crear ningún usuario) si alguna área viene mal formada.
	 *
	 * @param mixed $areas_input Valor crudo del parámetro `areas` de la petición (se espera un array de objetos, o null/vacío/ausente).
	 * @return array|WP_Error Lista de áreas normalizadas ({nombre, cupos, fecha_expiracion} en formato yyyy-mm-dd), vacía si no se enviaron áreas, o WP_Error si alguna es inválida.
	 */
	public static function validar_y_normalizar_areas( $areas_input ) {
		if ( null === $areas_input || '' === $areas_input || array() === $areas_input ) {
			return array();
		}

		if ( ! is_array( $areas_input ) ) {
			return new WP_Error( 'areas_invalidas', __( '"areas" debe ser un arreglo de objetos.', 'user-data-api' ) );
		}

		$normalizadas = array();

		foreach ( $areas_input as $indice => $area ) {
			$posicion = (int) $indice + 1;

			if ( ! is_array( $area ) ) {
				return new WP_Error(
					'area_invalida',
					sprintf(
						/* translators: %d: posición del área dentro del arreglo "areas" (base 1). */
						__( 'El área en la posición %d no es un objeto válido.', 'user-data-api' ),
						$posicion
					)
				);
			}

			$nombre = isset( $area['nombre'] ) ? sanitize_text_field( trim( (string) $area['nombre'] ) ) : '';

			if ( '' === $nombre ) {
				return new WP_Error(
					'area_nombre_requerido',
					sprintf(
						/* translators: %d: posición del área dentro del arreglo "areas" (base 1). */
						__( 'El área en la posición %d debe tener "nombre".', 'user-data-api' ),
						$posicion
					)
				);
			}

			$cupos_crudo = isset( $area['cupos'] ) ? $area['cupos'] : null;
			$cupos       = is_numeric( $cupos_crudo ) ? absint( $cupos_crudo ) : 0;

			if ( $cupos < 1 ) {
				return new WP_Error(
					'area_cupos_invalido',
					sprintf(
						/* translators: 1: nombre del área. 2: posición del área dentro del arreglo "areas" (base 1). */
						__( 'El área "%1$s" (posición %2$d) debe tener "cupos" como un número entero mayor o igual a 1.', 'user-data-api' ),
						$nombre,
						$posicion
					)
				);
			}

			$fecha_cruda = isset( $area['fecha_expiracion'] ) ? trim( (string) $area['fecha_expiracion'] ) : '';

			if ( '' === $fecha_cruda ) {
				// Igual que en el modal "Crear Área" (que precarga la fecha
				// con hoy + 6 meses): si no se envía, se usa ese mismo valor
				// por defecto en vez de exigirla siempre.
				$fecha_yyyy_mm_dd = self::fecha_por_defecto();
			} else {
				$fecha_yyyy_mm_dd = self::normalizar_fecha_yyyymmdd( $fecha_cruda );

				if ( false === $fecha_yyyy_mm_dd ) {
					return new WP_Error(
						'area_fecha_invalida',
						sprintf(
							/* translators: 1: nombre del área. 2: posición del área dentro del arreglo "areas" (base 1). */
							__( 'El área "%1$s" (posición %2$d) tiene un "fecha_expiracion" inválido.', 'user-data-api' ),
							$nombre,
							$posicion
						)
					);
				}

				if ( $fecha_yyyy_mm_dd < current_time( 'Y-m-d' ) ) {
					return new WP_Error(
						'area_fecha_pasada',
						sprintf(
							/* translators: 1: nombre del área. 2: posición del área dentro del arreglo "areas" (base 1). */
							__( 'El área "%1$s" (posición %2$d) tiene un "fecha_expiracion" anterior a hoy.', 'user-data-api' ),
							$nombre,
							$posicion
						)
					);
				}
			}

			$normalizadas[] = array(
				'nombre'           => $nombre,
				'cupos'            => $cupos,
				'fecha_expiracion' => $fecha_yyyy_mm_dd,
			);
		}

		return $normalizadas;
	}

	/**
	 * Crea una nueva área para una empresa ya existente.
	 *
	 * @param int    $empresa_id       ID de la empresa (grupo_id / user_id de la empresa).
	 * @param string $nombre           Nombre del área (ya sanitizado/no vacío).
	 * @param int    $cupos            Cupo del área (entero, ya validado >= 1).
	 * @param string $fecha_expiracion Fecha de expiración en formato yyyy-mm-dd (ya normalizada/validada).
	 * @return array|WP_Error {
	 *     @type int    $id               ID del área creada.
	 *     @type string $nombre           Nombre del área.
	 *     @type int    $cupos            Cupos del área.
	 *     @type string $fecha_expiracion Fecha de expiración (yyyy-mm-dd).
	 * }
	 */
	public static function crear_area( $empresa_id, $nombre, $cupos, $fecha_expiracion ) {
		global $wpdb;

		$tabla_areas = $wpdb->prefix . 'areas';

		$insertado = $wpdb->insert(
			$tabla_areas,
			array(
				'nombre'           => $nombre,
				'cupo'             => $cupos,
				'estado'           => 'Activado',
				'tipo'             => 'companies',
				'grupo_id'         => absint( $empresa_id ),
				'fecha_expiracion' => $fecha_expiracion,
			),
			array( '%s', '%d', '%s', '%s', '%d', '%s' )
		);

		if ( false === $insertado ) {
			return new WP_Error( 'area_error_insercion', __( 'Ocurrió un error al crear el área en la base de datos.', 'user-data-api' ) );
		}

		return array(
			'id'               => (int) $wpdb->insert_id,
			'nombre'           => $nombre,
			'cupos'            => $cupos,
			'fecha_expiracion' => $fecha_expiracion,
		);
	}

	/**
	 * Fecha de expiración por defecto cuando no se envía una para un área:
	 * hoy + 6 meses, exactamente el mismo cálculo que precarga el campo
	 * "Fecha de expiración" al abrir el modal "Crear Área" en Administrar
	 * Empresa Octágono (`calcularFechaPorDefecto()` en su admin.js).
	 *
	 * @return string Fecha en formato yyyy-mm-dd.
	 */
	public static function fecha_por_defecto() {
		return date( 'Y-m-d', strtotime( '+6 months', current_time( 'timestamp' ) ) ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
	}

	/**
	 * Normaliza una fecha recibida (posiblemente en distintos formatos) a
	 * yyyy-mm-dd, igual que `aeo_normalizar_fecha_yyyymmdd()` del plugin
	 * "Administrar Empresa Octágono".
	 *
	 * @param string $fecha Fecha recibida.
	 * @return string|false Fecha en formato yyyy-mm-dd, o false si no es válida.
	 */
	public static function normalizar_fecha_yyyymmdd( $fecha ) {
		if ( empty( $fecha ) ) {
			return false;
		}

		$timestamp = strtotime( $fecha );

		if ( false === $timestamp ) {
			return false;
		}

		return date( 'Y-m-d', $timestamp );
	}
}
