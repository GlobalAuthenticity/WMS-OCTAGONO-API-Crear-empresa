<?php
/**
 * Registro y lógica del endpoint REST de creación de empresas.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Company_Api {

	/**
	 * Namespace de la REST API.
	 *
	 * @var string
	 */
	const NAMESPACE = 'user-data-api/v1';

	/**
	 * Ruta del endpoint dentro del namespace.
	 *
	 * @var string
	 */
	const ROUTE = '/company';

	/**
	 * Módulo de autenticación (mismo Bearer Token que el resto de la API).
	 *
	 * @var UDA_Auth
	 */
	private $auth;

	/**
	 * Constructor.
	 *
	 * @param UDA_Auth $auth Instancia del módulo de autenticación.
	 */
	public function __construct( UDA_Auth $auth ) {
		$this->auth = $auth;
	}

	/**
	 * Registra los hooks necesarios de WordPress.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Registra la ruta REST `POST /user-data-api/v1/company`.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => WP_REST_Server::CREATABLE, // POST.
				'callback'            => array( $this, 'handle_request' ),
				'permission_callback' => array( $this->auth, 'check_bearer_token' ),
				'args'                => array(
					// Sin 'type' ni 'sanitize_callback' a propósito: así se
					// acepta tanto string vacío como `null` explícito sin que
					// la validación automática de esquema de WP los rechace
					// antes de llegar a la lógica de negocio, que es quien
					// decide autogenerar el correo cuando falta.
					'user_email'       => array(
						'required'    => false,
						'description' => __( 'Correo electrónico. Si se omite, es null o llega vacío, se autogenera a partir de nombre_empresa.', 'user-data-api' ),
					),
					'nombre_empresa'   => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					// Sin 'type' ni 'sanitize_callback' en 'nombre_encargado',
					// 'contacto' y 'ocupacion': se acepta string vacío o
					// `null` explícito sin que la validación de esquema de
					// WP los rechace antes de que la lógica de negocio
					// aplique el valor por defecto de cada uno.
					'nombre_encargado' => array(
						'required'    => false,
						'description' => __( 'Nombre del encargado. Si se omite, es null o llega vacío, se usa "José Martínez".', 'user-data-api' ),
					),
					'contacto'         => array(
						'required'    => false,
						'description' => __( 'Teléfono de contacto. Si se omite, es null o llega vacío, se genera uno aleatorio.', 'user-data-api' ),
					),
					'ocupacion'        => array(
						'required'    => false,
						'description' => __( 'Ocupación. Si se omite, es null o llega vacía, se usa "Administrador WMS".', 'user-data-api' ),
					),
					// Sin 'type' ni 'sanitize_callback': se valida y sanitiza
					// a mano en UDA_Area::validar_y_normalizar_areas(), que
					// necesita poder distinguir "no se envió" de "se envió
					// mal formado" con más detalle del que permite el
					// esquema automático de WP para un array de objetos.
					'areas'            => array(
						'required'    => false,
						'description' => __( 'Lista opcional de áreas a crear para la empresa. Cada elemento: {"nombre": string (obligatorio), "cupos": entero >= 1 (obligatorio), "fecha_expiracion": "YYYY-MM-DD" (opcional, por defecto hoy + 6 meses)}.', 'user-data-api' ),
					),
				),
			)
		);
	}

	/**
	 * Callback principal: valida los parámetros, crea la empresa (usuario
	 * con rol `group_admin`) y sus áreas (si se enviaron) reutilizando
	 * `UDA_Company::crear_empresa_con_areas()` — la misma función que usa
	 * la herramienta de prueba del panel de administración, para que
	 * ambas nunca puedan divergir — y devuelve el resultado.
	 *
	 * @param WP_REST_Request $request Petición REST entrante.
	 * @return WP_REST_Response
	 */
	public function handle_request( WP_REST_Request $request ) {
		$user_email       = $request->get_param( 'user_email' );
		$nombre_empresa   = $request->get_param( 'nombre_empresa' );
		$nombre_encargado = $request->get_param( 'nombre_encargado' );
		$contacto         = $request->get_param( 'contacto' );
		$ocupacion        = $request->get_param( 'ocupacion' );
		$areas            = $request->get_param( 'areas' );

		$resultado = UDA_Company::crear_empresa_con_areas( $user_email, $nombre_empresa, $nombre_encargado, $contacto, $ocupacion, $areas );

		if ( is_wp_error( $resultado ) ) {
			// Los códigos de conflicto (nombre/correo ya usados) van con
			// 409; cualquier otro error (incluyendo los de "areas" mal
			// formadas) es un 400 de validación.
			$codigos_conflicto = array( 'usuario_existente', 'empresa_existente' );
			$status            = in_array( $resultado->get_error_code(), $codigos_conflicto, true ) ? 409 : 400;

			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $resultado->get_error_message(),
				),
				$status
			);
		}

		return new WP_REST_Response(
			array(
				'success'            => true,
				'message'            => __( 'La empresa se ha registrado correctamente.', 'user-data-api' ),
				'empresa'            => array(
					'user_id'        => $resultado['usuario_id'],
					'nombre_empresa' => $nombre_empresa,
					// $resultado['user_email'] es el correo FINAL (el
					// enviado, o el autogenerado si no se envió uno); nunca
					// el parámetro crudo de la petición, que pudo llegar
					// vacío o null.
					'email'          => $resultado['user_email'],
					'password'       => $resultado['password'],
					'rol'            => 'company',
				),
				'areas'              => $resultado['areas'],
				'defaults_aplicados' => $resultado['defaults_aplicados'],
			),
			201
		);
	}
}
