<?php
/**
 * Configuración del plugin (token de autenticación) vía Settings API.
 *
 * @package User_Data_API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UDA_Settings {

	/**
	 * Nombre de la opción de WordPress donde se guarda el token.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'uda_bearer_token';

	/**
	 * Grupo de opciones registrado en la Settings API.
	 *
	 * @var string
	 */
	const OPTION_GROUP = 'uda_settings_group';

	/**
	 * Registra los hooks necesarios de WordPress.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Registra la opción del token en la Settings API, con su propia
	 * sanitización. `register_setting()` se encarga de aplicar el nonce
	 * de `options.php` automáticamente a través de `settings_fields()`.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_token' ),
				'default'           => '',
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Sanitiza el token recibido desde el formulario de administración.
	 *
	 * Solo se permiten caracteres seguros para un token (alfanuméricos y
	 * un puñado de símbolos habituales en tokens generados), evitando
	 * que se guarde HTML o espacios accidentales.
	 *
	 * @param mixed $value Valor recibido del formulario.
	 * @return string
	 */
	public function sanitize_token( $value ) {
		$value = is_string( $value ) ? trim( $value ) : '';
		$value = preg_replace( '/[^A-Za-z0-9\-_.]/', '', $value );

		return (string) $value;
	}

	/**
	 * Devuelve el token configurado actualmente.
	 *
	 * @return string
	 */
	public function get_token() {
		return (string) get_option( self::OPTION_NAME, '' );
	}

	/**
	 * Genera un token aleatorio criptográficamente seguro (vía la propia
	 * función nativa de WordPress `wp_generate_password()`, sin
	 * caracteres especiales para que sea seguro de usar directamente en
	 * una cabecera HTTP).
	 *
	 * @return string
	 */
	public function generate_token() {
		return wp_generate_password( 48, false, false );
	}
}
