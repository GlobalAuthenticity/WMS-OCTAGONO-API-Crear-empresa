/* global jQuery, UDA_ADMIN */
(function ($) {
	'use strict';

	function debounce(fn, wait) {
		var timer;
		return function () {
			var context = this;
			var args = arguments;
			clearTimeout(timer);
			timer = setTimeout(function () {
				fn.apply(context, args);
			}, wait);
		};
	}

	/**
	 * Copia texto al portapapeles y da feedback visual momentáneo en el
	 * botón que disparó la acción (cambia su texto a "¡Copiado!" y vuelve
	 * a su etiqueta original después de 1.6s).
	 */
	function copyToClipboard(text, $btn, originalLabel) {
		function feedback() {
			if (!$btn || !$btn.length) {
				return;
			}
			var label = UDA_ADMIN.i18n.copied || 'Copiado';
			$btn.text(label);
			setTimeout(function () {
				$btn.text(originalLabel);
			}, 1600);
		}

		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(feedback, feedback);
			return;
		}

		// Fallback para navegadores/contextos sin Clipboard API.
		var $tmp = $('<textarea>').val(text).css({ position: 'fixed', top: '-9999px' });
		$('body').append($tmp);
		$tmp[0].select();
		try {
			document.execCommand('copy');
		} catch (e) {
			// Silencioso: si falla, simplemente no hay feedback de "copiado".
		}
		$tmp.remove();
		feedback();
	}

	function escapeHtml(str) {
		return $('<div>').text(str === null || typeof str === 'undefined' ? '' : String(str)).html();
	}

	/**
	 * Inicializa la herramienta de prueba de la página "API Crear empresa"
	 * (creación real de una empresa, sin Postman, vía AJAX del admin).
	 */
	function initCompanyPage() {
		var $createBtn = $('#uda-company-create-btn');

		if (!$createBtn.length) {
			return;
		}

		var $email = $('#uda-company-email');
		var $nombre = $('#uda-company-nombre');
		var $encargado = $('#uda-company-encargado');
		var $contacto = $('#uda-company-contacto');
		var $ocupacion = $('#uda-company-ocupacion');
		var $areas = $('#uda-company-areas');
		var $status = $('#uda-company-status');
		var $output = $('#uda-company-output');
		var $result = $('#uda-company-result');
		var $resultInfo = $('#uda-company-result-info');

		function infoTile(label, value) {
			var $tile = $('<div>', { class: 'uda-info-tile' });
			$tile.append($('<span>', { class: 'uda-info-label', text: label }));
			$tile.append($('<span>', { class: 'uda-info-value', text: value }));
			return $tile;
		}

		$createBtn.on('click', function () {
			var email = $.trim($email.val());
			var nombreEmpresa = $.trim($nombre.val());
			var areasTexto = $.trim($areas.val());

			if (!nombreEmpresa) {
				$status.text(UDA_ADMIN.i18n.companyRequired);
				return;
			}

			if (areasTexto) {
				try {
					JSON.parse(areasTexto);
				} catch (e) {
					$status.text(UDA_ADMIN.i18n.areasInvalidJson);
					return;
				}
			}

			$status.text(UDA_ADMIN.i18n.creatingCompany);
			$output.text('');
			$result.prop('hidden', true);
			$createBtn.prop('disabled', true);

			$.post(UDA_ADMIN.ajaxUrl, {
				action: 'uda_crear_empresa_test',
				nonce: UDA_ADMIN.nonce,
				user_email: email,
				nombre_empresa: nombreEmpresa,
				nombre_encargado: $encargado.val(),
				contacto: $contacto.val(),
				ocupacion: $ocupacion.val(),
				areas: areasTexto
			})
				.done(function (res) {
					if (res && res.success && res.data && res.data.response) {
						var response = res.data.response;
						var empresa = response.empresa || {};
						var areasCreadas = response.areas || [];

						$output.text(JSON.stringify(response, null, 2));
						$status.text('');

						$resultInfo.empty();
						$resultInfo.append(infoTile('ID', '#' + empresa.user_id));
						$resultInfo.append(infoTile('Empresa', empresa.nombre_empresa));
						$resultInfo.append(infoTile('Correo', empresa.email));
						$resultInfo.append(infoTile('Contraseña', empresa.password));
						$resultInfo.append(infoTile('Rol', empresa.rol));
						$resultInfo.append(infoTile('Defaults aplicados', (response.defaults_aplicados || []).join(', ') || '—'));

						var areasTexto2 = areasCreadas.length
							? areasCreadas.map(function (area) {
								return area.success
									? area.nombre + ' (#' + area.id + ', ' + area.cupos + ' cupos, vence ' + area.fecha_expiracion + ')'
									: area.nombre + ' — error: ' + area.message;
							}).join(' · ')
							: '—';
						$resultInfo.append(infoTile('Áreas creadas', areasTexto2));

						$result.prop('hidden', false);

						$email.val('');
						$nombre.val('');
						$encargado.val('');
						$contacto.val('');
						$ocupacion.val('');
						$areas.val('');
					} else {
						var msg = (res && res.data && res.data.message) || UDA_ADMIN.i18n.error;
						$status.text(msg);
					}
				})
				.fail(function () {
					$status.text(UDA_ADMIN.i18n.error);
				})
				.always(function () {
					$createBtn.prop('disabled', false);
				});
		});
	}

	/**
	 * Descarga como archivo .md el contenido de documentación embebido en
	 * la página, dentro de un <textarea hidden> (ver class-uda-admin.php,
	 * esc_textarea()): un textarea decodifica sus entidades HTML al leer
	 * `.val()` sin interpretar ninguna etiqueta, así que el contenido
	 * llega intacto tal cual se generó en PHP. Cada botón indica, vía
	 * data-attributes, qué textarea descargar y con qué nombre de
	 * archivo; así un mismo manejador sirve para ambas páginas ("API info
	 * usuario" y "API Crear empresa") sin duplicar lógica.
	 */
	function initDocDownloads() {
		$('.uda-download-doc').on('click', function () {
			var $btn = $(this);
			var targetId = $btn.data('doc-target');
			var filename = $btn.data('filename') || 'documentacion.md';
			var $source = $('#' + targetId);

			if (!$source.length) {
				return;
			}

			var content = $source.val();

			var blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
			var url = window.URL.createObjectURL(blob);

			var $link = $('<a>', { href: url, download: filename });
			$('body').append($link);
			$link[0].click();
			$link.remove();

			setTimeout(function () {
				window.URL.revokeObjectURL(url);
			}, 1000);
		});
	}

	$(function () {
		/* ---------- Descargar documentación .md (ambas páginas) ---------- */

		initDocDownloads();

		/* ---------- Copiar bloques de código (ambas páginas) ---------- */

		$('.uda-copy-btn').on('click', function () {
			var $btn = $(this);
			var targetId = $btn.data('copy-target');
			var $target = $('#' + targetId);
			var originalLabel = $btn.text();

			if (!$target.length) {
				return;
			}

			copyToClipboard($target.text(), $btn, originalLabel);
		});

		/* ---------- Copiar token (campo de solo lectura, página "API Crear empresa") ---------- */

		$('#uda-copy-company-token').on('click', function () {
			var $btn = $(this);
			copyToClipboard($('#uda-company-token-field').val(), $btn, UDA_ADMIN.i18n.copy || 'Copiar');
		});

		/* ---------- Página "API info usuario" ---------- */

		var $generateBtn = $('#uda-generate-token');
		var $tokenField = $('#uda-token-field');
		var $roleFilter = $('#uda-role-filter');
		var $testFilter = $('#uda-test-filter');
		var $searchInput = $('#uda-user-search');
		var $userSelect = $('#uda-user-select');
		var $previewBtn = $('#uda-preview-btn');
		var $status = $('#uda-preview-status');
		var $output = $('#uda-preview-output');
		var $result = $('#uda-preview-result');
		var $resultName = $('#uda-result-name');
		var $resultEmail = $('#uda-result-email');
		var $resultBadges = $('#uda-result-badges');
		var $resultInfo = $('#uda-result-info');
		var $resultCourses = $('#uda-result-courses');

		if (!$generateBtn.length) {
			initCompanyPage();
			return;
		}

		$('#uda-copy-token').on('click', function () {
			var $btn = $(this);
			copyToClipboard($tokenField.val(), $btn, UDA_ADMIN.i18n.copy || 'Copiar');
		});

		/* ---------- Generar token ---------- */

		$generateBtn.on('click', function () {
			var hasToken = $.trim($tokenField.val()) !== '';

			if (hasToken && !window.confirm(UDA_ADMIN.i18n.confirmRegen)) {
				return;
			}

			$generateBtn.prop('disabled', true);

			$.post(UDA_ADMIN.ajaxUrl, {
				action: 'uda_generate_token',
				nonce: UDA_ADMIN.nonce
			})
				.done(function (res) {
					if (res && res.success && res.data && res.data.token) {
						$tokenField.val(res.data.token);
						$status.text(UDA_ADMIN.i18n.tokenGenerated);
					} else {
						$status.text(UDA_ADMIN.i18n.error);
					}
				})
				.fail(function () {
					$status.text(UDA_ADMIN.i18n.error);
				})
				.always(function () {
					$generateBtn.prop('disabled', false);
				});
		});

		/* ---------- Búsqueda de usuarios ---------- */

		function searchUsers() {
			var term = $searchInput.val();

			$userSelect.prop('disabled', true);
			$userSelect.empty().append(
				$('<option>', { value: '', text: UDA_ADMIN.i18n.searching })
			);

			$.post(UDA_ADMIN.ajaxUrl, {
				action: 'uda_search_users',
				nonce: UDA_ADMIN.nonce,
				term: term,
				role: $roleFilter.val(),
				test: $testFilter.val()
			})
				.done(function (res) {
					var items = (res && res.success && res.data && res.data.items) || [];
					var $sel = $userSelect.empty();

					$sel.append(
						$('<option>', { value: '', text: '— Selecciona un usuario —' })
					);

					if (!items.length) {
						$sel.append(
							$('<option>', { value: '', text: UDA_ADMIN.i18n.noResults, disabled: true })
						);
					}

					items.forEach(function (item) {
						$sel.append($('<option>', { value: item.id, text: item.label }));
					});
				})
				.fail(function () {
					$userSelect.empty().append(
						$('<option>', { value: '', text: UDA_ADMIN.i18n.error })
					);
				})
				.always(function () {
					$userSelect.prop('disabled', false);
				});
		}

		searchUsers();

		$searchInput.on('keyup', debounce(searchUsers, 350));
		$roleFilter.on('change', searchUsers);
		$testFilter.on('change', searchUsers);

		/* ---------- Previsualización visual ---------- */

		function badge(label, modifier) {
			return $('<span>', { class: 'uda-badge uda-badge--' + modifier, text: label });
		}

		function infoTile(label, value, muted) {
			var $tile = $('<div>', { class: 'uda-info-tile' });
			$tile.append($('<span>', { class: 'uda-info-label', text: label }));
			$tile.append($('<span>', { class: 'uda-info-value' + (muted ? ' uda-info-value--muted' : ''), text: value }));
			return $tile;
		}

		function courseStatusBadge(course) {
			if (course.completed) {
				return badge(UDA_ADMIN.i18n.courseCompleted, 'success');
			}
			if (course.progress_percentage > 0) {
				return badge(UDA_ADMIN.i18n.courseInProgress, 'info');
			}
			return badge(UDA_ADMIN.i18n.courseNotStarted, 'neutral');
		}

		function renderResult(user) {
			$resultName.text(user.full_name || user.username || ('#' + user.id));
			$resultEmail.text(user.email || '');

			$resultBadges.empty();
			$resultBadges.append(
				user.profile && user.profile.completed
					? badge(UDA_ADMIN.i18n.profileComplete, 'success')
					: badge(UDA_ADMIN.i18n.profileIncomplete, 'warning')
			);
			$resultBadges.append(
				user.test && user.test.completed
					? badge(UDA_ADMIN.i18n.testDone, 'info')
					: badge(UDA_ADMIN.i18n.testPending, 'neutral')
			);

			$resultInfo.empty();
			$resultInfo.append(infoTile('ID', '#' + user.id));
			$resultInfo.append(infoTile('Roles', (user.roles || []).join(', ') || '—', true));
			$resultInfo.append(
				user.company
					? infoTile('Empresa', user.company.name)
					: infoTile('Empresa', UDA_ADMIN.i18n.noCompany, true)
			);
			$resultInfo.append(
				user.area
					? infoTile('Área', user.area.name)
					: infoTile('Área', UDA_ADMIN.i18n.noArea, true)
			);
			if (user.area && user.area.membership && user.area.membership.status) {
				$resultInfo.append(infoTile('Estado membresía', user.area.membership.status));
			}

			$resultCourses.empty();
			var courses = user.courses || [];

			if (!courses.length) {
				$resultCourses.append($('<p>', { class: 'uda-empty-state', text: UDA_ADMIN.i18n.noCourses }));
			} else {
				courses.forEach(function (course) {
					var pct = Math.max(0, Math.min(100, parseInt(course.progress_percentage, 10) || 0));

					var $row = $('<div>', { class: 'uda-course-row' });
					var $top = $('<div>', { class: 'uda-course-top' });
					$top.append($('<span>', { class: 'uda-course-title', text: course.title || ('#' + course.id) }));
					$top.append(courseStatusBadge(course));
					$row.append($top);

					var $track = $('<div>', { class: 'uda-progress-track' });
					$track.append($('<div>', { class: 'uda-progress-fill', css: { width: pct + '%' } }));
					$row.append($track);

					$row.append($('<div>', { class: 'uda-course-percent', text: pct + '% · ' + (course.completed_steps || 0) + '/' + (course.total_steps || 0) }));

					$resultCourses.append($row);
				});
			}

			$result.prop('hidden', false);
		}

		$previewBtn.on('click', function () {
			var userId = $userSelect.val();

			if (!userId) {
				$status.text(UDA_ADMIN.i18n.selectUser);
				return;
			}

			$status.text(UDA_ADMIN.i18n.loading);
			$output.text('');
			$result.prop('hidden', true);
			$previewBtn.prop('disabled', true);

			$.post(UDA_ADMIN.ajaxUrl, {
				action: 'uda_preview_user',
				nonce: UDA_ADMIN.nonce,
				user_id: userId
			})
				.done(function (res) {
					if (res && res.success && res.data && res.data.response) {
						$output.text(JSON.stringify(res.data.response, null, 2));
						$status.text('');

						var user = res.data.response.user;
						if (user) {
							renderResult(user);
						}
					} else {
						var msg = (res && res.data && res.data.message) || UDA_ADMIN.i18n.error;
						$status.text(msg);
					}
				})
				.fail(function () {
					$status.text(UDA_ADMIN.i18n.error);
				})
				.always(function () {
					$previewBtn.prop('disabled', false);
				});
		});
	});
})(jQuery);
