<?php
/**
 * Limpieza al desinstalar el plugin.
 *
 * @package User_Data_API
 */

// Si no se llama desde WordPress al desinstalar, salir.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'uda_bearer_token' );
