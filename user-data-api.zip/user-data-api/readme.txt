=== User Data API (Octógono WMS) ===
Contributors: wmslatam
Tags: rest-api, learndash, usuarios, api
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.12.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Endpoints REST personalizados (POST), protegidos con Bearer Token: consulta de la información completa de un usuario del ecosistema WMS Latam (perfil, empresa, área, cursos de LearnDash y resultados del test) y creación de empresas (usuarios con rol group_admin).

== Description ==

**User Data API** expone dos rutas REST equivalentes (mismo comportamiento, mismos parámetros):

    POST /wp-json/user-data-api/v1/user      (original)
    POST /wp-json/user-data-api/v1/lookup    (alterna — recomendada)

La ruta alterna existe porque varios plugins de seguridad (Wordfence entre ellos) traen reglas de firewall que bloquean por patrón cualquier ruta REST terminada en "/user" o "/users", como protección genérica contra enumeración de usuarios — esas reglas no distinguen el namespace, solo el sufijo de la URL, así que pueden bloquear esta ruta por error aunque no tenga relación con el endpoint de usuarios del core de WordPress. Si tu sitio usa un firewall así, usa `/lookup` en vez de `/user`; ambas devuelven exactamente lo mismo.

Ambas rutas permiten consultar, mediante `user_id` o `email`, toda la información relevante de un usuario:

* Datos básicos (ID, email, username, nombre, apellido, nombre completo, roles, fecha de registro).
* Estado del perfil (`profile.completed`), usando el mismo criterio de 7 campos ya usado en el resto del ecosistema WMS Latam (first_name, last_name, user_age, user_gender, country, phone_number, user_position).
* Empresa y área, resueltas mediante las tablas reales del proyecto (`wp_user_members` + `wp_areas`), las mismas que usan los plugins "Administrar Empresa Octágono" y "Áreas Asignadas". `wp_user_members` liga cada usuario a un área (`area_id`, `status`, `fecha_final_membresia`); `wp_areas` guarda los datos del área (nombre, cupo, estado, fecha de expiración) y su `grupo_id`, que es el ID del usuario-empresa. La empresa es, en sí, un usuario de WordPress con rol `group_admin`. Este proyecto no usa `wp_correos_configurados` ni `wp_paquetes` (son de otro proyecto del ecosistema).
* Cursos de LearnDash asignados, con progreso, lecciones completadas/totales y estado, usando las funciones oficiales de LearnDash (`learndash_get_user_course_access_list()`, `learndash_course_progress()`, `learndash_course_status()`).
* Test del usuario (`question_test_ids` en `wp_usermeta`) y sus resultados del test "Sentido Vital" (Escala Dimensional del Sentido de vida): promedio (`suma_de_valores / 17`) y clasificación en uno de 4 niveles (Búsqueda / Medio / Alto sentido vital / Plenitud de sentido), calculados con exactamente la misma fórmula y los mismos umbrales (2.65 / 2.35 / 2.00) que usa el tema en la página pública `/resultado-test/` (`astra-child/assets/js/result.js`) y en los informes por área/empresa (`get-test-result-by-area-id.php` / `get-test-result-by-group.php`) — no se reinventa el cálculo, se replica.

Además, expone una tercera ruta para crear empresas:

    POST /wp-json/user-data-api/v1/company

Protegida con el mismo Bearer Token que las rutas anteriores. Recibe `nombre_empresa` (obligatorio y único, sin distinguir mayúsculas/minúsculas) y `user_email`, `nombre_encargado`, `contacto`, `ocupacion` (opcionales), y crea un usuario de WordPress con rol `group_admin` — mismos campos y misma lógica de negocio que el botón "Crear Empresa" del plugin "Administrar Empresa Octágono", replicada aquí de forma autocontenida para que el endpoint no dependa de que aquel plugin esté activo.

Si `user_email` se omite, llega vacío (`""`) o llega `null`, se autogenera con el formato `admin.(slug)@wmslatam.com`, donde `slug` es `nombre_empresa` en minúsculas, sin acentos, sin caracteres especiales/espacios y sin la palabra "demo" (se ignora como palabra completa, en cualquier posición del nombre). Si tras esa limpieza no queda ningún carácter (ej. `nombre_empresa` = "Demo" o "¡¡¡!!!"), se usa un slug de respaldo aleatorio. Si el correo autogenerado ya existe, se agrega automáticamente un sufijo numérico (o, en último caso, aleatorio) hasta encontrar uno libre.

Igual que `user_email`, `nombre_encargado`, `contacto` y `ocupacion` también son completamente opcionales: si se omiten, llegan vacíos o llegan `null`, se completan automáticamente — `nombre_encargado` con `José Martínez`, `contacto` con un número telefónico aleatorio de 10 dígitos (formato celular colombiano, empieza en "3", sin validar duplicados porque es solo un dato de relleno) y `ocupacion` con `Administrador WMS`.

Opcionalmente, también se pueden crear áreas para la empresa en la misma petición, enviando `areas` (arreglo), replicando los mismos campos y la misma lógica de negocio que el botón "Crear Área" del modal de áreas de "Administrar Empresa Octágono":

    "areas": [
      { "nombre": "Ventas", "cupos": 20 },
      { "nombre": "Recursos Humanos", "cupos": 5, "fecha_expiracion": "2027-03-23" }
    ]

Cada área necesita `nombre` y `cupos` (entero >= 1); `fecha_expiracion` es opcional (formato `AAAA-MM-DD`, no puede ser anterior a hoy) y si se omite se usa hoy + 6 meses, igual que el valor precargado por defecto en ese mismo modal. Si CUALQUIER área del arreglo viene mal formada, la petición completa se rechaza con 400 y no se crea ni la empresa ni ninguna área — evita dejar una empresa creada sin las áreas que se pidieron junto con ella. Este sitio no tiene tabla de licencias ni código de área (a diferencia de otros sitios del ecosistema WMS Latam): si se envían `codigo` o `licencia_id` dentro de un área, se aceptan sin error pero no se guardan en ningún lado.

Si `areas` se omite, llega vacío o llega `null` (no se pidió ninguna área), se crea automáticamente **una** área por defecto: `Área demo`, 2 cupos, `fecha_expiracion` = hoy + 6 meses. Así, ninguna empresa creada por esta API queda sin ninguna área.

La respuesta exitosa (201) devuelve los datos de la empresa anidados en `empresa` (`user_id`, `nombre_empresa`, `email`, `password`, `rol`), más `areas` (un resultado por cada área enviada, o por el área "Área demo" por defecto si no se envió ninguna — nunca queda `[]` — cada una con `id`, `nombre`, `cupos`, `fecha_expiracion` y `success: true`, o `success: false` y `message` si esa área puntual falló al insertarse ya con la empresa creada) y `defaults_aplicados` (lista de los campos opcionales que se completaron automáticamente, incluyendo `'areas'` cuando se usó el área por defecto). `empresa.password` es la contraseña generada en texto plano — este endpoint no envía correo de bienvenida ni sincroniza con otro sitio, así que es el único canal para entregarla; quien consuma la API es responsable de transmitirla de forma segura.

Incluye un panel de administración completo, con dos páginas (submenús "API info usuario" y "API Crear empresa") para configurar el token y para previsualizar/probar exactamente lo que la API devolvería, sin necesidad de Postman.

= Seguridad =

* Autenticación por Bearer Token, comparado con `hash_equals()` (evita timing attacks).
* Si no hay token configurado, el endpoint rechaza TODAS las peticiones (nunca queda abierto por accidente).
* El endpoint solo devuelve información de UN usuario por petición (por ID o correo exactos); no permite listar ni enumerar usuarios.
* No se expone `user_pass`, hashes, activation keys ni ningún otro metadato sensible de `wp_usermeta`. Excepción explícita: `POST /company` sí devuelve, en `empresa.password`, la contraseña recién generada (no un hash ni un dato preexistente) porque es el único canal para entregarla al no haber sincronización externa ni correo de bienvenida.
* Todas las consultas a la base de datos usan `$wpdb->prepare()`.
* El panel de administración usa la Settings API de WordPress (nonces, sanitización, `current_user_can( 'manage_options' )`); todas las acciones AJAX validan nonce y capacidad.
* Usa `$wpdb->prefix` en vez de asumir que el prefijo de tablas es siempre `wp_`.

== Installation ==

1. Ve a **Plugins → Añadir plugin → Subir plugin** en tu escritorio de WordPress.
2. Selecciona el archivo `user-data-api.zip` y pulsa **Instalar ahora**.
3. Activa el plugin.
4. Al activarse se genera automáticamente un token aleatorio. Ve a **User Data API** en el menú de administración (icono de API) para verlo, copiarlo o generar uno nuevo.
5. Pulsa **Guardar cambios** después de cambiar el token.

== Dónde configurar el token ==

Escritorio de WordPress → **User Data API** (menú lateral) → sección "Configuración de la API" → campo "Token de autenticación". Puedes generar uno seguro automáticamente con el botón "Generar token seguro" (recuerda pulsar "Guardar cambios" para aplicarlo).

== Endpoint ==

    POST /wp-json/user-data-api/v1/user

=== Headers ===

    Authorization: Bearer TU_TOKEN
    Content-Type: application/json

=== Parámetros aceptados (body JSON) ===

Envía **uno** de los dos:

* `user_id` (entero) — ID del usuario en WordPress.
* `email` (string) — correo electrónico del usuario.

Si se envían ambos, `user_id` tiene prioridad.

== Ejemplo de petición ==

    curl -X POST 'https://tu-sitio.com/wp-json/user-data-api/v1/lookup' \
      -H 'Authorization: Bearer TU_TOKEN' \
      -H 'Content-Type: application/json' \
      -d '{"email":"usuario@ejemplo.com"}'

O por ID:

    curl -X POST 'https://tu-sitio.com/wp-json/user-data-api/v1/lookup' \
      -H 'Authorization: Bearer TU_TOKEN' \
      -H 'Content-Type: application/json' \
      -d '{"user_id":123}'

(La ruta `/user` original funciona exactamente igual; `/lookup` es la recomendada por si tu firewall bloquea rutas terminadas en "/user".)

== Ejemplo de respuesta (200) ==

    {
      "success": true,
      "user": {
        "id": 123,
        "email": "usuario@ejemplo.com",
        "username": "usuario",
        "first_name": "Juan",
        "last_name": "Pérez",
        "full_name": "Juan Pérez",
        "roles": ["subscriber"],
        "registered_at": "2026-01-01 10:00:00",
        "profile": {
          "completed": true
        },
        "company": {
          "id": 10,
          "name": "Empresa Ejemplo",
          "email": "contacto@empresa-ejemplo.com"
        },
        "area": {
          "id": 5,
          "name": "Recursos Humanos",
          "quota": 20,
          "status": "Activado",
          "expires_at": "2026-12-31",
          "membership": {
            "status": "ACTIVO",
            "expires_at": "31-12-2026"
          }
        },
        "courses": [
          {
            "id": 120,
            "title": "Curso de ejemplo",
            "status": "in_progress",
            "progress_percentage": 65,
            "completed_steps": 13,
            "total_steps": 20,
            "completed": false
          }
        ],
        "test": {
          "completed": true,
          "question_test_ids": [
            { "question": 1, "answer": 2, "value": 1 }
          ],
          "results": {
            "average": 2.12,
            "scale": { "min": 0, "max": 3, "question_count": 17 },
            "classification": {
              "key": "medio-sentido",
              "label": "Medio sentido vital",
              "description": "Personas que entienden algunas de las razones por las que actúan en su vida, pero en ciertas áreas pueden experimentar cierta desmotivación.",
              "range": { "min": 2, "max": 2.34 }
            },
            "levels": [
              { "key": "busqueda-sentido", "label": "Búsqueda de sentido vital", "description": "...", "range": { "min": 0, "max": 1.99 } },
              { "key": "medio-sentido", "label": "Medio sentido vital", "description": "...", "range": { "min": 2, "max": 2.34 } },
              { "key": "alto-sentido", "label": "Alto sentido vital", "description": "...", "range": { "min": 2.35, "max": 2.64 } },
              { "key": "plenitud-sentido", "label": "Plenitud de sentido", "description": "...", "range": { "min": 2.65, "max": 3 } }
            ]
          }
        }
      }
    }

Si el usuario no tiene empresa/área asignada, `company` y/o `area` se devuelven como `null`. Si no ha realizado el test:

    "test": {
      "completed": false,
      "question_test_ids": null,
      "results": null
    }

== Posibles códigos de error ==

* **400 Bad Request** — no se envió `user_id` ni `email`, o el formato del correo no es válido.
  `{"success": false, "message": "Debes enviar \"user_id\" o \"email\"."}`
* **401 Unauthorized** — falta la cabecera `Authorization`, el formato no es `Bearer TOKEN`, no hay token configurado en el servidor, o el token es inválido.
  `{"code": "uda_unauthorized", "message": "Token inválido.", "data": {"status": 401}}`
* **404 Not Found** — no existe ningún usuario con ese ID/correo.
  `{"success": false, "message": "Usuario no encontrado."}`
* **200 OK** — éxito, con el objeto `user` completo.

== Frequently Asked Questions ==

= ¿Por qué a veces `results` viene en `null` aunque el test esté completado? =

Solo ocurre si `question_test_ids` no se puede decodificar como un array de respuestas válido (dato corrupto). En cualquier otro caso el promedio y la clasificación se calculan siempre en el propio plugin (no dependen de que el tema `astra-child` esté activo); `question_test_ids` sigue devolviendo las respuestas crudas del usuario de todos modos.

= ¿Por qué `courses` viene vacío? =

LearnDash (plugin `sfwd-lms`) no está activo, o el usuario no tiene ningún curso asignado.

= ¿Puedo consultar todos los usuarios de una vez? =

No. Por diseño, el endpoint solo permite consultar un usuario por vez mediante su ID o correo exactos, para evitar la enumeración masiva de usuarios.

== Changelog ==

= 1.12.0 =
* Ambas páginas del panel de administración ("API info usuario" y "API Crear empresa") ahora incluyen un botón "Descargar documentación (.md)" en su encabezado, que genera y descarga un archivo Markdown independiente por endpoint (`user-data-api-consultar-usuario.md` y `user-data-api-crear-empresa.md`), con la especificación completa del endpoint (autenticación, headers, parámetros, estructura de respuesta, códigos de error y ejemplos completos de petición/respuesta) pensada para que un agente de IA la use como referencia de integración. El token Bearer se documenta con el marcador `TU_TOKEN_AQUI` en vez del token real del sitio.

= 1.11.0 =
* `POST /wp-json/user-data-api/v1/company`: si `areas` se omite, llega vacío o llega `null` (no se pidió ninguna área), ahora se crea automáticamente un área por defecto: "Área demo", 2 cupos, `fecha_expiracion` = hoy + 6 meses. `areas` en la respuesta ya no queda `[]` en ese caso, y `defaults_aplicados` incluye `'areas'` cuando se aplicó.

= 1.10.0 =
* `POST /wp-json/user-data-api/v1/company`: nuevo parámetro opcional `areas` (arreglo) para crear áreas de la empresa en la misma petición, replicando la lógica del botón "Crear Área" de "Administrar Empresa Octágono" (campos `nombre`, `cupos`, `fecha_expiracion` opcional con valor por defecto hoy + 6 meses).
* Se valida y normaliza TODO el arreglo `areas` antes de crear la empresa: si cualquier área viene mal formada (sin nombre, cupos inválidos, fecha inválida o pasada), la petición completa se rechaza con 400 y no se crea nada.
* La respuesta 201 ahora devuelve en `areas` un resultado por cada área enviada, en vez de siempre `[]`.
* Nota: este sitio no tiene tabla de licencias ni columna de código de área, así que `codigo`/`licencia_id` dentro de un área se aceptan sin error pero no se persisten.
* La herramienta de prueba de "API Crear empresa" ahora incluye un campo para probar la creación de áreas junto con la empresa (JSON libre).

= 1.9.0 =
* `POST /wp-json/user-data-api/v1/company`: `nombre_empresa` ahora debe ser único (sin distinguir mayúsculas/minúsculas). Si ya existe una empresa registrada con ese nombre, se rechaza con 409 y código de error `empresa_existente`, sin crear el usuario.

= 1.8.1 =
* `POST /wp-json/user-data-api/v1/company`: se quita `empresa.autologin_url` de la respuesta 201 (tanto del endpoint REST como de la herramienta de prueba del admin). El usuario de autologin sigue generándose internamente (metas `mi_autologin_token`/`mi_autologin_expires`), simplemente ya no se expone en la respuesta.

= 1.8.0 =
* **Cambio en la forma de la respuesta exitosa (201) de `POST /wp-json/user-data-api/v1/company`** (no compatible con integraciones que ya parseaban la forma plana anterior):
  * Los datos de la empresa ahora van anidados bajo `empresa` (`user_id`, `nombre_empresa`, `email`, `password`, `rol`, `autologin_url`), en vez de ir sueltos en la raíz.
  * Se agrega `empresa.password`: la contraseña generada, en texto plano. Antes NUNCA se devolvía; ahora sí, porque este endpoint no envía correo de bienvenida ni sincroniza con otro sitio, así que es el único canal para entregarla. Quien consuma la API es responsable de transmitirla de forma segura.
  * Se agrega `empresa.rol`, con el valor fijo `"company"` (etiqueta legible; el rol real de WordPress sigue siendo `group_admin`, sin cambios).
  * Se agrega `areas` (array, siempre vacío: este endpoint no crea áreas).
  * Se agrega `defaults_aplicados` (array de strings) con los nombres de los campos opcionales que llegaron vacíos/null/ausentes y se completaron automáticamente (valores posibles: `email`, `nombre_encargado`, `contacto`, `ocupacion`).
  * `message` cambia de "Empresa creada correctamente." a "La empresa se ha registrado correctamente.".
  * La forma de la respuesta de error (400/409) no cambia.

= 1.7.3 =
* `POST /wp-json/user-data-api/v1/company`: `nombre_encargado` ahora también tiene valor por defecto. Si se omite, llega vacío o llega `null`, se guarda "José Martínez" en vez de dejar el campo en blanco.

= 1.7.2 =
* `POST /wp-json/user-data-api/v1/company`: `contacto` ahora también tiene valor por defecto. Si se omite, llega vacío o llega `null`, se genera un número telefónico aleatorio de 10 dígitos (formato celular colombiano) en vez de dejar el campo en blanco.

= 1.7.1 =
* `POST /wp-json/user-data-api/v1/company`: `ocupacion` ahora también tiene valor por defecto. Si se omite, llega vacía o llega `null`, se guarda "Administrador WMS" en vez de dejar el campo en blanco.

= 1.7.0 =
* `POST /wp-json/user-data-api/v1/company`: `user_email` ahora es opcional. Si se omite, llega vacío o llega `null`, se autogenera un correo `admin.(slug)@wmslatam.com` a partir de `nombre_empresa` (minúsculas, sin acentos, sin caracteres especiales/espacios y sin la palabra "demo" como palabra completa). Se agrega sufijo numérico automático si el correo generado ya existe. La respuesta siempre incluye el `user_email` final (el enviado o el autogenerado).
* El formulario de prueba de "API Crear empresa" ya no exige correo electrónico, solo nombre de la empresa.

= 1.6.0 =
* Nuevo endpoint `POST /wp-json/user-data-api/v1/company` para crear empresas (usuarios con rol `group_admin`), protegido con el mismo Bearer Token del resto de la API. Replica la lógica de negocio del botón "Crear Empresa" del plugin "Administrar Empresa Octágono" (mismos campos: `user_email`, `nombre_empresa`, `nombre_encargado`, `contacto`, `ocupacion`), de forma autocontenida en este plugin.
* El panel de administración ahora tiene dos submenús: "API info usuario" (el panel existente, sin cambios de comportamiento) y "API Crear empresa" (documentación del nuevo endpoint + herramienta para crear una empresa real desde el admin sin Postman).

= 1.5.0 =
* `company` y `area` ahora se resuelven con las tablas reales de este proyecto (`wp_user_members` + `wp_areas`, rol `group_admin`), en vez de la lógica de `wp_correos_configurados`/`wp_paquetes` de otro proyecto del ecosistema que no aplica aquí (por eso siempre venían en `null`). `area` ahora incluye además `quota`, `status`, `expires_at` y el estado de la membresía del usuario (`membership.status`, `membership.expires_at`). Se elimina el campo `license` (`company.license` / `area.license`): este proyecto no tiene tabla `wp_licencias` ni concepto de licencia asociado a empresa/área.

= 1.4.0 =
* `test.results` ahora refleja la interpretación real del test de este proyecto ("Sentido Vital" / Escala Dimensional del Sentido de vida, página pública `/resultado-test/`), en vez de la lógica de "vulnerabilidades / amenazas / estrategias" de otro proyecto del ecosistema que no aplica aquí (esas funciones — `proccessResultUserTestWMS()`, `get_test_reglas()` — nunca existieron en este tema, por lo que `results` venía siempre en `null`). Ahora calcula el promedio (`suma_de_valores / 17`) y lo clasifica en Búsqueda / Medio / Alto sentido vital / Plenitud de sentido, con exactamente los mismos umbrales que usan `astra-child/assets/js/result.js` y los informes por área/empresa. Se agregó `test.results.levels` con los 4 niveles posibles (etiqueta, descripción y rango), para que un consumidor de la API tenga la escala completa sin tener que duplicarla.

= 1.3.2 =
* Se agregó una ruta REST alterna equivalente: `POST /wp-json/user-data-api/v1/lookup`, con exactamente el mismo comportamiento, permisos y parámetros que `/user`. Motivo: algunos firewalls (Wordfence, entre otros) bloquean por patrón cualquier ruta REST terminada en "/user" o "/users" como protección genérica anti-enumeración de usuarios, sin distinguir el namespace — eso puede bloquear por error esta ruta aunque no tenga relación con el endpoint de usuarios del core de WordPress. La ruta original `/user` se mantiene activa por compatibilidad; `/lookup` es la recomendada para instalaciones con ese tipo de firewall.

= 1.3.1 =
* Rediseño completo de la interfaz del panel de administración con identidad visual del ecosistema WMS Latam (tipografía Plus Jakarta Sans/Inter, paleta azul de marca + acento amarillo + casi-negro, tarjetas, badges de estado, previsualización visual del usuario con tarjetas de información y barras de progreso de cursos, botones de "Copiar" para token/cURL/JSON). No cambia el endpoint, la autenticación ni la lógica de datos: es exclusivamente un cambio de interfaz.

= 1.3.0 =
* `company` y `area` ahora incluyen su licencia asociada (`license`), resuelta desde `wp_licencias` (nombre, duración y las 9 banderas `incluir_*` que determinan los módulos habilitados), igual que `LicenseQueries` en el tema. `null` si no tienen licencia asignada.

= 1.2.1 =
* El botón "Generar token seguro" ahora guarda el token de inmediato (antes solo lo rellenaba en el campo hasta pulsar "Guardar cambios", lo que podía perderse al salir de la página sin guardar y parecer "temporal"). El token es fijo entre peticiones, recargas y reactivaciones del plugin; solo cambia al generarlo de nuevo o al editarlo a mano y guardar.

= 1.2.0 =
* `test.results` ahora incluye `interpretation`: la misma lectura por categorías (Áreas profundas de mejora / Detonantes / Estrategias, niveles bajo/medio/alto, nombres amigables) que ya muestra la página pública `/resultado-test-trabajador/`, en vez de solo los totales numéricos crudos.

= 1.1.0 =
* La previsualización de usuario ahora incluye filtros por rol y por estado del test (realizó / no ha realizado), aplicados antes de buscar y seleccionar el usuario.

= 1.0.0 =
* Versión inicial: endpoint REST, panel de configuración del token y herramienta de previsualización.
