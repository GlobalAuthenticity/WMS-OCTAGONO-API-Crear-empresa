<?php
/**
 * Plugin Name:       User Data API (Octógono WMS)
 * Plugin URI:        https://wmslatam.com
 * Description:       Expone endpoints REST API (POST) protegidos con Bearer Token: consultar la información completa de un usuario (perfil, empresa, área, cursos de LearnDash y resultados del test) a partir de su ID o correo electrónico, y crear una empresa (usuario con rol group_admin), opcionalmente junto con sus áreas, con autogeneración de varios campos si no se envían.
 * Version:           1.12.0
 * Author:            Cristian
 * Author URI:        https://wmslatam.com
 * Text Domain:       user-data-api
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 *
 * @package User_Data_API
 */

// Evitar acceso directo al archivo.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Constantes principales del plugin.
 */
define( 'UDA_VERSION', '1.12.0' );
define( 'UDA_PLUGIN_FILE', __FILE__ );
define( 'UDA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'UDA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'UDA_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Autoload / carga centralizada de las clases del plugin.
 */
require_once UDA_PLUGIN_DIR . 'includes/class-uda-loader.php';

/**
 * Punto de entrada del plugin.
 *
 * Se registra en `plugins_loaded` para asegurar que WordPress y demás
 * plugins dependientes (LearnDash) ya estén disponibles antes de
 * inicializar el plugin.
 *
 * @return void
 */
function uda_init() {
	UDA_Loader::init();
}
add_action( 'plugins_loaded', 'uda_init' );

/**
 * Hook de activación: genera un token por defecto (si no existe uno) para
 * que el endpoint nunca quede completamente abierto justo después de
 * activar el plugin, y refresca las reglas de reescritura para que la
 * ruta REST quede disponible de inmediato.
 *
 * @return void
 */
function uda_activate() {
	require_once UDA_PLUGIN_DIR . 'includes/class-uda-settings.php';

	$settings = new UDA_Settings();

	if ( '' === $settings->get_token() ) {
		update_option( UDA_Settings::OPTION_NAME, $settings->generate_token() );
	}

	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'uda_activate' );

/**
 * Hook de desactivación: refresca las reglas de reescritura.
 *
 * @return void
 */
function uda_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'uda_deactivate' );
